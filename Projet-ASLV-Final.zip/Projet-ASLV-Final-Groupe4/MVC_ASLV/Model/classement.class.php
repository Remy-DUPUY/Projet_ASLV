<?php

class Classement{
  private $nom_equipe;
  private $position_equipe;
  private $points_equipe;
  private $nb_rencontres_jouees;
  private $nb_rencontres_gagnees;
  private $nb_rencontres_perdues;
  private $nb_rencontres_nulles;

    /* Les getters */
  function getNomEquipe():string{
    return $this->nom_equipe;
  }

  function getPositionEquipe():int{
    return $this->position_equipe;
  }

  function getNbPointsEquipe():int{
    return $this->points_equipe;
  }

  function getNbRencontres_jouees():int{
    return $this->nb_rencontres_jouees;
  }

  function getNbRencontres_gagnees():int{
    return $this->nb_rencontres_gagnees;
  }

  function getNbRencontres_perdues():int{
      return $this->nb_rencontres_perdues;
  }

  function getNbRencontres_nulles():int{
    return $this->nb_rencontres_nulles;
  }

  /* Les setters */

  function setNomEquipe(string $un_Nom_equipe):void{
     $this->nom_equipe = $un_Nom_equipe;
  }

  function setPositionEquipe(int $une_position):void{
     $this->position_equipe = $une_position;
  }

  function setNbPointsEquipe(int $nb_de_points):void{
    $this->points_equipe = $nb_de_points;
  }

  function setNbRencontres_jouees(int $nb_rencontres_J):void{
      $this->nb_rencontres_jouees = $nb_rencontres_J;
  }

  function setNbRencontres_gagnees(int $nb_rencontres_G):void{
    $this->nb_rencontres_gagnees = $nb_rencontres_G;
  }

  function setNbRencontres_perdues(int $nb_rencontres_P):void{
      $this->nb_rencontres_perdues = $nb_rencontres_P;
  }

  function setNbRencontres_nulles(int $nb_rencontres_N):void{
    $this->nb_rencontres_nulles = $nb_rencontres_N;
  }
}
 ?>
