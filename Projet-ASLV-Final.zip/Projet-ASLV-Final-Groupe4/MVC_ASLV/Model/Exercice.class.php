<?php

    // Un Exercice
    class Exercice {
        private $id_p;          // Identifiant unique de l'exercice
        private $nom_exo;         // Nom de l'exercice
        private $nb_serie;       // Nombre de séries
        private $nb_repetition;  // Nombre de répétitions
        private $temps_repos;       // Durée de la pause en sec

        // Getters
        function getId() : int {
          return $this->id_p;
        }

        function getNom() : string {
          return $this->nom_exo;
        }

        function getSerie() : int {
          return $this->nb_serie;
        }

        function getRepetition() : int {
          return $this->nb_repetition;
        }

        function getRepos() : int {
          return $this->temps_repos;
        }

    }

?>
