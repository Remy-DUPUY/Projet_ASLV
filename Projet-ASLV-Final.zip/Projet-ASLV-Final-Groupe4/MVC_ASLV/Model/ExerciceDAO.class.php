<?php
    class ExerciceDAO {
        private $bdd;
        // L'objet local PDO de la base de donnée
        // Constructeur chargé d'ouvrir la BD
        function __construct() {
          try {
              $this->bdd = new \PDO('mysql:dbname=ki404559_ProjetS3;host=localhost:3306;charset=utf8','ki404559_test','MotDePass123456789');
              //$this->bdd = new PDO('mysql:host=localhost;dbname=bdd_aslv', 'root', 'root');
          } catch (Exception $e) {
              print("$e");
              exit;
          }
        }


        // Accès à toutes les exercices
        // Retourne une table d'objets de type Exercice
        function getAllExercices() : array {
          $req_getAllPreparations = $this->bdd->prepare("SELECT * FROM preparations");
          $req_getAllPreparations ->execute();
          $req_getAllPreparations = $req_getAllPreparations ->fetchAll(PDO::FETCH_CLASS, 'Exercice');
          return $req_getAllPreparations ;
        }

        // cette fonction va avoir pour but de verifier si l'email existe deja donc si lutilitateur a deja un compte
        function exo_exist(string $nom_exo):bool {
          $req_exo_exist = $this->bdd->prepare("SELECT * FROM preparations WHERE nom_exo = ?");
          $req_exo_exist->execute(array(strtolower($nom_exo)));
          $res_exo_exist = $req_exo_exist->rowCount();

          if($res_email_exist == 1) {
            return true;
          } else {
            return false;
          }
        }

        /*function getLastId() : int {
          //récupération du dernier id
          $req = "SELECT id FROM exercice ORDER BY id DESC LIMIT 1" ;
          $sth=$bdd->query($req);
          $tab = $sth->fetchAll(PDO::FETCH_CLASS, "Exercice");
          if($tab!=NULL){
            return $tab[0]->getId();
          }else{
            return -1;
          }
        }*/

        function insertExercice(string $nom, int $serie, int $rep, int $pause) {
            $req_insert_system = $this->bdd->prepare('INSERT INTO preparations(nom_exo, nb_serie, nb_repetition, temps_repos)
                                      VALUES(:nom_exo, :nb_serie, :nb_repetition, :temps_repos)');

            $req_insert_system->execute(array(
              'nom_exo' => $nom,
              'nb_serie' => $serie,
              'nb_repetition' => $rep,
              'temps_repos' => $pause)
            );
        }

        function deleteExercice(int $id) {
          echo "id = $id";
            $req_insert_system = $this->bdd->prepare('DELETE FROM preparations WHERE id_p = ?');
            $req_insert_system->execute(array($id));
        }
/*
        // Acces à la base de donnée
        function getDb() : PDO {
          return $this->bdd;
        }
*/
    }

    ?>
