<?php
  require_once('membre.class.php');
  require_once('membreDAO.class.php');

  $membre = new MembreDAO();

  // on cree un objet membre JOUEUSES
  $UneJoeuse = $membre->getMembre("joueuses");
  var_dump($UneJoeuse);

  $res_joueuses = $membre->speudo_exist("joueuses");
  echo "<br>Qu'elle est votre pseudo : ".$UneJoeuse->get_pseudo();
  echo "<br>Qu'elle est votre id : ".$UneJoeuse->get_id_membre();
  echo "<br>Qu'elle est votre mot de passe : ".$UneJoeuse->get_password();
  echo "<br>Etes-vous administrateur (1 = vrai / 0 = faux) : ".$UneJoeuse->get_admin();
    echo "<br>Le pseudo COACH existe t'il ? (1 = vrai / 0 = faux) : ".$membre->speudo_exist("JOUEUSES");
  echo "<br><br><br><br><br><br>";

  // on cree un objet membre COACH
  $UnCoach = $membre->getMembre("CoaCh");
  var_dump($UnCoach);

  $res_coach = $membre->speudo_exist("joueuses");
  echo "<br>Qu'elle est votre pseudo : ".$UnCoach->get_pseudo();
  echo "<br>Qu'elle est votre id : ".$UnCoach->get_id_membre();
  echo "<br>Qu'elle est votre mot de passe : ".$UnCoach->get_password();
  echo "<br>Etes-vous administrateur (1 = vrai / 0 = faux) : ".$UnCoach->get_admin();
  echo "<br>Le pseudo COACH existe t'il ? (1 = vrai / 0 = faux) : ".$membre->speudo_exist("COACH");
?>
