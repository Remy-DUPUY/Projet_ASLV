<?php
  class SystemeDAO {
    private $bdd;

    function __construct(){
      // on ouvre la connexion avec la base de données

      try {
        $this->bdd = new \PDO('mysql:dbname=ki404559_ProjetS3;host=localhost:3306;charset=utf8','ki404559_test','MotDePass123456789');
        // $this->bdd = new PDO('mysql:host=localhost;dbname=bdd_aslv', 'root', 'root');
      } catch (\PDOException $e) {
        die("erreur de connexion : ".$e->getMessage());
      }
    }

    function get(string $s_file):Systeme {
      // on regarde si le nom du systeme n'existe pas déjà ( si il est base)
      $req_get = $this->bdd->prepare("SELECT * FROM systemes WHERE nom_systeme = ?");
      $req_get->execute(array($s_file));
      $res = $req_get->fetchAll(PDO::FETCH_CLASS, 'Systeme');
      return $res[0];
    }

    function getAll():Array {
      // on recupere tous les systems
      $req_system = $this->bdd->prepare("SELECT * FROM systemes ORDER BY date_creation DESC");
      $req_system->execute();
      $system_all = $req_system->fetchAll();
      return $system_all;
    }

    function exists(string $s_file):int {
      // on regarde si le nom du systeme n'existe pas déjà ( si il est base)
      $req_system = $this->bdd->prepare("SELECT * FROM systemes WHERE nom_systeme = ?");
      $req_system->execute(array($s_file));
      $system_exist = $req_system->rowCount();
      return $system_exist;
    }

    function insert(string $s_file):void {
      date_default_timezone_set('Europe/Paris');
      // on ajoute en base le system
      $id_fichier = uniqid();
      $dateNow = date('d/m/Y - H:i');
      $req_insert_system = $this->bdd->prepare('INSERT INTO systemes(id_systeme, nom_systeme, date_creation)
                                                VALUES(:id_systeme, :nom_systeme, :date_creation)');
      $req_insert_system->execute(array(
                   'id_systeme' => $id_fichier,
                   'nom_systeme' => $s_file,
                   'date_creation' => $dateNow));
    }

    function delete(String $s_file):void {
      $Unsysteme = $this->get($s_file);
      $id_systeme = $Unsysteme->getIdSysteme();
      //var_dump($Unsysteme->getIdSysteme());
      // $req_suppr_schema = $this->bdd->prepare("DELETE FROM schemas WHERE id_systeme = ?");
      // $req_suppr_schema->execute(array($id_systeme));

      $req_suppr = $this->bdd->prepare("DELETE FROM systemes WHERE id_systeme = ?");
      $req_suppr->execute(array($id_systeme));
      unlink("../Model/data/".$s_file);
    }

    function setDescription(string $s_file, string $description):void {
      $Unsysteme = $this->get($s_file);
      $id_systeme = $Unsysteme->getIdSysteme();
      $Unsysteme->setDescription($description);

      $req_description = $this->bdd->prepare("UPDATE systemes SET description = ? WHERE id_systeme = ?");
      $req_description->execute(array($description,$id_systeme));
    }

    function setNom(string $s_file, string $nom):string {
      if ($this->exists($nom) == 0) {
        $Unsysteme = $this->get($s_file);
        $id_systeme = $Unsysteme->getIdSysteme();

        $req_description = $this->bdd->prepare("UPDATE systemes SET nom_systeme = ? WHERE id_systeme = ?");
        $req_description->execute(array($nom,$id_systeme));
        $Unsysteme->setNom($nom);
        //Rename fichier json
        if (rename("../Model/data/".$s_file,"../Model/data/".$nom)) {
          return "Changement de nom réussi";
        } else {
          return "Problème de connexion : Rename non réussi";
        }
      } else {
        return "Nom déjà existant";
      }
    }
  }
?>
