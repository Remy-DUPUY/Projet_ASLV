<?php
  class Membre {
    private $id_membre;
    private $pseudo;
    private $password;
    private $admin;

    function get_id_membre():string  {
      return $this->id_membre;
    }
    function get_pseudo():string {
      return $this->pseudo;
    }
    function get_password():string {
      return $this->password;
    }
    function get_admin():bool {
      return $this->admin;
    }
}
?>
