<?php
  class Systeme {
    private $id_systeme;
    private $nom_systeme;
    private $date_creation;
    private $description;

    function getIdSysteme():String {
      return $this->id_systeme;
    }

    function getNomSysteme() {
      return $this->nom_systeme;
    }

    function getDateCreation() {
      return $this->date_creation;
    }

    function getDescription() {
      return $this->description;
    }

    function setDescription(string $nouvelle_description) {
      $this->description = $nouvelle_description;
    }

    function setNom(string $nouveau_nom) {
      $this->nom_systeme = $nouveau_nom;
    }
  }
?>
