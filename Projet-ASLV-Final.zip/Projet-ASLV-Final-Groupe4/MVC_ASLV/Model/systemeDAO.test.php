<?php
  require_once('../Model/systemeDAO.class.php');
  require_once('../Model/systeme.class.php');
  $systeme = new SystemeDAO();

  // tout les systeme enregistré
  var_dump($systeme->getAll());
  echo "<br>";

  // juste un systeme
  $nom_systeme = "salut.json";
  $unsysteme = $systeme->get($nom_systeme);
  var_dump($unsysteme);
  echo "<br>";

  //test des geteur
  echo "id:".$unsysteme->getIdSysteme(); echo "<br>";
  echo "id:".$unsysteme->getNomSysteme(); echo "<br>";
  echo "id:".$unsysteme->getDateCreation(); echo "<br>";
  echo "id:".$unsysteme->getDescription(); echo "<br>";

  // delete
  $systeme->delete($nom_systeme);
  var_dump($systeme->getAll());
 ?>
