<?php
require_once("../Model/classement.class.php");

class ClassementDAO{
private $bdd;
// Constructeur
  function __construct(){
    try {
      //$this->bdd = new PDO('mysql:host=localhost;dbname=projets3d','root', 'root');
      $this->bdd = new \PDO('mysql:dbname=ki404559_ProjetS3;host=localhost:3306;charset=utf8','ki404559_test','MotDePass123456789');
    } catch (\PDOException $e) {
      die("erreur de connexion : ".$e->getMessage());
    }
  }
  //////////////////////////////////////////////////////////
  //                   METHODES                           //
  //////////////////////////////////////////////////////////
  function getInfosSite(string $adresseSite):array {
    $tabClassements = array();
  //Recuperation de la chaine sur laquelle on va travailler
    $content = file_get_contents($adresseSite);

  //recuperation de la partie de la chaine qui est utile 
    $res = strpos($content,'table class="liste"');
    $partie1 = substr($content,$res); 

    $res2 = strpos($partie1,'<tr class="altern-2"');
    $partie2 = substr($partie1,$res2);

  //on travaille desormais sur la chaine $partie2
    //on recupere la chaine dans un tableau temporaire
    $tab = explode('>',$partie2);
    $posInfoDep = 2;

    //on recupere chaque classement qu'on ajoute dans le tableau a retourner ($tabClassements)

    while($posInfoDep<=count($tab)) {
      $objetClassement = new Classement();
      //Remplissage du numero dans le classement
      $chainePropre = explode('<',$tab[$posInfoDep]);
      $objetClassement->setPositionEquipe(intval($chainePropre[0]));
      $posInfoDep = $posInfoDep+3;

      //Remplissage du nom de l'equipe
      $chainePropre = explode('<',$tab[$posInfoDep]);
      $objetClassement->setNomEquipe($chainePropre[0]);
      $posInfoDep = $posInfoDep+3;

      //Remplissage du nb points de l'equipe
      $chainePropre = explode('<',$tab[$posInfoDep]);
      $objetClassement->setNbPointsEquipe(intval($chainePropre[0]));
      $posInfoDep = $posInfoDep+2;

      //Remplissage du nb de rencontres
      $chainePropre = explode('<',$tab[$posInfoDep]);
      $objetClassement->setNbRencontres_jouees(intval($chainePropre[0]));
      $posInfoDep = $posInfoDep+2;

      //Remplissage du nb de rencontres gagnees
      $chainePropre = explode('<',$tab[$posInfoDep]);
      $objetClassement->setNbRencontres_gagnees(intval($chainePropre[0]));
      $posInfoDep = $posInfoDep+2;

      //Remplissage du nb de rencontres perdues
      $chainePropre = explode('<',$tab[$posInfoDep]);
      $objetClassement->setNbRencontres_perdues(intval($chainePropre[0]));
      $posInfoDep = $posInfoDep+2;

      //Remplissage du nb de rencontres nulles
      $chainePropre = explode('<',$tab[$posInfoDep]);
      $objetClassement->setNbRencontres_nulles(intval($chainePropre[0]));

      array_push($tabClassements,$objetClassement);
      $posInfoDep = $posInfoDep+26;
    }
    //suppression du dernier element qui ne contient pas un classement correcte
    unset($tabClassements[count($tabClassements)-1]);
    return $tabClassements;
  }

  function insereBDD(array $tab):void{
    //Requete pour preparer l'insertion dans la table classement
    $req = "INSERT INTO classement VALUES(:position,:nom,:points,:rencontreJ,:rencontreG,:rencontreP,:rencontreN)";
    $stmt = $this->bdd->prepare($req);
    foreach($tab as $elem) {
      //on recupere les elements des objets classements pour y inserer dans la table classement
      $stmt->execute(array(
        ':position'=>$elem->getPositionEquipe(),
        ':nom'=>$elem->getNomEquipe(),
        ':points'=>$elem->getNbPointsEquipe(),
        ':rencontreJ'=>$elem->getNbRencontres_jouees(),
        ':rencontreG'=>$elem->getNbRencontres_gagnees(),
        ':rencontreP'=>$elem->getNbRencontres_perdues(),
        ':rencontreN'=>$elem->getNbRencontres_nulles()
      ));
    }
  }

  function updateBDD(array $tab):void{
    //Requete pour preparer la MAJ dans la table classement
    $req = "UPDATE classement SET nom_equipe= :nom, points_equipe=:points, nb_rencontres_jouees=:rencontreJ, nb_rencontres_gagnees=:rencontreG,
    nb_rencontres_perdues=:rencontreP, nb_rencontres_nulles=:rencontreN
    WHERE position_equipe=:numEquipe";

    $stmt = $this->bdd->prepare($req);
    foreach($tab as $elem) {
      //on recupere les elements des objets classements pour mettre a jour la table classement
      $stmt->execute(array(
        ':nom'=>$elem->getNomEquipe(),
        ':points'=>$elem->getNbPointsEquipe(),
        ':rencontreJ'=>$elem->getNbRencontres_jouees(),
        ':rencontreG'=>$elem->getNbRencontres_gagnees(),
        ':rencontreP'=>$elem->getNbRencontres_perdues(),
        ':rencontreN'=>$elem->getNbRencontres_nulles(),
        ':numEquipe'=>$elem->getPositionEquipe()
      ));
    }
  }

  //permet de savoir si des elements existent dans la table classement
  function estVide():bool {
    $req = "SELECT * FROM classement";
    $stmt = $this->bdd->prepare($req);
    $stmt->execute();
    $result = $stmt->fetchAll(PDO::FETCH_CLASS,'Classement');
    if(empty($result)) {
      //si $result est vide on renvoie vrai
      return TRUE;
    }else {
      //si $result n'est pas vide on renvoie faux
      return FALSE;
    }
    
  }

  //retouner toutes les equipes presentes dans la table classement
  function getEquipesClassement():array{
    $req = "SELECT * FROM classement ORDER BY position_equipe ";
    $stmt = $this->bdd->prepare($req);
    $stmt->execute();
    $tabEquipes = $stmt->fetchAll(PDO::FETCH_CLASS, 'Classement');
    return $tabEquipes;
  }
}
?>
