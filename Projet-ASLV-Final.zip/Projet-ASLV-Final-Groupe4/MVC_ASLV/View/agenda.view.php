<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Agenda ASLV</title>
    <style media="screen">
      body {
        text-align: center;
      }

      div {
        padding-top: 2%;
        margin-bottom: 20%;
      }

      #logo_agenda {
        background-color: #D5DBDB;
      }

      @media only screen and (max-width:1000px) {
        h1 {
          zoom: 200%;
        }
      }

    </style>
  </head>
  <body>
    <h1>Agenda</h1>
    <div class="">
      <iframe src="https://calendar.google.com/calendar/b/2/embed?height=1150&amp;wkst=2&amp;bgcolor=%23c82619&amp;ctz=Europe%2FParis&amp;src=Z2VzdGlvbmFzbHZAZ21haWwuY29t&amp;src=ZnIuZnJlbmNoI2hvbGlkYXlAZ3JvdXAudi5jYWxlbmRhci5nb29nbGUuY29t&amp;color=%23039BE5&amp;color=%230B8043&amp;showTitle=0&amp;showNav=1&amp;showDate=0&amp;mode=WEEK&amp;showPrint=0&amp;showCalendars=0&amp;showTabs=0&amp;showTz=0"
      style="border-width:0" width="100%" height="1150" frameborder="0" scrolling="no"></iframe>
    </div>

    <?php include("../View/menu.view.php") ?>
  </body>
</html>
