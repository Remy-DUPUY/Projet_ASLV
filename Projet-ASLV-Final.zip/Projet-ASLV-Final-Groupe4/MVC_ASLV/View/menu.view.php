<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <style media="screen">
      nav {
        position: fixed;
        bottom: -16px;
        left: -0.5px;
        width: 100%;
      }

      nav > ul {
        list-style-type: none;
        padding-left: 0;
        margin-top: 0;
        display: flex;
        justify-content: space-around;
        align-items: center;
        background-color: white;
        height: 60px;
        border: 3px solid #c82619;
      }

      a > img {
        width: 3.4em;
        height: 3.4em;
      }

      nav > ul > li {
        padding-top: 1px;
      }

      @media only screen and (max-width:1000px) {
        nav > ul {
          list-style-type: none;
          padding-left: 0;
          margin-top: 0;
          display: flex;
          justify-content: space-around;
          align-items: center;
          background-color: white;
          height: 115px;
          border: 3px solid #c82619;
        }

        a > img {
          width: 6.9em;
          height: 6.9em;
        }
      }

    </style>
  </head>
  <body>
    <nav>
      <ul>
        <li id="logo_classement"><a href="../Controler/classement.ctrl.php"><img src="../View/img/logo_classement1.png"> </a></li>
        <li id="logo_systemes"><a href="../Controler/systemes.ctrl.php"><img src="../View/img/logo_systeme1.png"></a></li>
        <li id="logo_agenda"><a href="../Controler/agenda.ctrl.php"><img src="../View/img/logo_agenda1.png"></a></li>
        <li id="logo_prepa"><a href="../Controler/exercice.ctrl.php"><img src="../View/img/logo_prepa1.png"></a></li>
      </ul>
    </nav>
  </body>
</html>
