<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <style media="screen">
    </style>
    <link rel="stylesheet" href="../View/css/exercice.css"/>
  </head>
  <body>
    <script type="text/javascript">
      function attendre(){
        // recharge la page
        location.reload(true);
      }

      function supprimeExo(id){
        if(confirm("Voulez-vous supprimer l'exercice ?")){
          var dt = new FormData();
          dt.append('id_p', id);
          dt.append('yes', "true");

          var requeteAjax = new XMLHttpRequest();
          requeteAjax.open('POST', 'supprimerExo.ctrl.php');
          requeteAjax.send(dt);

          // attendre 1 sec avant d'actualiser la page
          setTimeout(attendre, 1);
        }
      }
    </script>

    <?php include("../View/menu.view.php"); ?>
  </body>
</html>
