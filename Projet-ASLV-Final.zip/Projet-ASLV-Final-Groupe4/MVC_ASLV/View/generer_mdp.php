<?php
  $mdp_hash = password_hash("EtreC0@chCestCh0uette", PASSWORD_DEFAULT);
  echo "coach: EtreC0@chCestCh0uette <br>";
  echo "hash: $mdp_hash <br><br><br>";

  $mdp_hash_2 = password_hash("EtreJ0ueusesCestCh0uette", PASSWORD_DEFAULT);
  echo "joueuses: EtreJ0ueusesCestCh0uette <br>";
  echo "hash: $mdp_hash_2 <br><br><br>";
?>
