<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>liste de schema</title>
    <style media="screen">
      .demi-container{
        width: 100%;
        margin: auto;
      }

      .top-container{
        width: 50%;
        margin: auto;
        display: flex;
        justify-content: space-around;
      }

      .btn-container a{ text-decoration: none; }

      .title{ text-align: center; }

      .img-plus > img{
        width: auto;
        height: 30px;
        margin-right: 15px;
      }

      .btn-container{
        display: flex;
        align-items: center;
      }

      .svg{
        display: flex;
        justify-content: center;
      }

      .btn-buttom-container{
        text-align: center;
      }

      .btn-buttom a {
        text-decoration: none;
      }

      .btn-add > input{
        background-color: #DAD9D9;
        border : solid 0.5em #C82619;
        border-radius: 10px;
        color: black;
        border: none;
        padding: 20px 30px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
      }

      .svg-container {
        margin-bottom: 20%;
      }

      /*Barre de menu*/
      #logo_systemes {
        background-color: #D5DBDB;
      }

      h1{
        margin-bottom: 0;
      }

      h4{
        text-align: center;
        margin-top: 0;
      }

    </style>
  </head>
  <body>

    <h1 class="title"><?= substr($this->nom_fichier, 0, strlen($this->nom_fichier)-5) ?> - Liste des schémas </h1>
    <a href="../Controler/systemes.ctrl.php"> <h4>revenir à la page systèmes</h4> </a>

    <?php
      // var_dump($this->tab_schema);
      if($this->btn == "envoyer") {
        echo "
          <div class=\"btn-buttom-container\">
            <a class=\"btn-add\" href=\"../Controler/dessiner_un_schema.ctrl.php?nom_fichier=$this->nom_fichier&nom_schema=\"><input type=\"button\" value=\"Ajouter un schéma\"></a>
          </div>
        ";
      }

        echo "<div class=\"svg-container\">";
          for ($n=0; $n < count($this->tab_schema); $n++) {
              echo "
                <div class=\"demi-container\">
                  <div class=\"top-container\">
                    <h2 class=\"title-second\"> ".$this->tab_titre_schema[$n]." : </h2>
        ";

          echo "<div class=\"btn-container\">";
          echo "<a class=\"img-plus\" href=\"../Controler/lire_un_schema.ctrl.php?nom_fichier=$this->nom_fichier&nom_schema=".$this->tab_name_schema[$n]."\"> <img src=\"../View/img/logo-zoom.png\" alt=\"zoom / agrandir schema\"> </a>";
          if($this->btn == "envoyer") {
             echo "
               <a class=\"img-plus\" href=\"../Controler/dessiner_un_schema.ctrl.php?nom_fichier=$this->nom_fichier&nom_schema=".$this->tab_name_schema[$n]."&titre_schema=".$this->tab_titre_schema[$n]."\"> <img src=\"../View/img/logo-edit.png\" alt=\"edit / modifier schema\"> </a>
               <a class=\"img-plus\" href=\"../Controler/dupliquer_un_schema.ctrl.php?nom_fichier=$this->nom_fichier&nom_schema=".$this->tab_name_schema[$n]."\"> <img src=\"../View/img/logo-duplicate.png\" alt=\"duplicate / copy - paste / depliquer schema\"> </a>
               <a class=\"img-plus\" href=\"../Controler/supprimer_un_schema.ctrl.php?nom_fichier=$this->nom_fichier&nom_schema=".$this->tab_name_schema[$n]."\"> <img src=\"../View/img/logo-trash.png\" alt=\"trash / delette / supprimer schema\"> </a>
             ";
          }
        echo "</div>";

        echo "
                  </div>
                  <div class=\"svg\">
                    <svg width=\"750\" height=\"535\">
                      <g>
                        <defs>
                          <pattern id=\"image\" patternUnits=\"userSpaceOnUse\" width=\"750\" height=\"535\">
                            <image x=\"0\" y=\"20\" width=\"750\" height=\"535\" xlink:href=\"../View/img/basket_horizontal.png\"></image>
                          </pattern>

                          <pattern id=\"image1\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" height=\"65\" width=\"65\" xlink:href=\"../View/img/maillot/1.png\"></image>
                          </pattern>
                          <pattern id=\"image2\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" height=\"65\" width=\"65\" xlink:href=\"../View/img/maillot/2.png\"></image>
                          </pattern>
                          <pattern id=\"image3\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" height=\"65\" width=\"65\" xlink:href=\"../View/img/maillot/3.png\"></image>
                          </pattern>
                          <pattern id=\"image4\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" height=\"65\" width=\"65\" xlink:href=\"../View/img/maillot/4.png\"></image>
                          </pattern>
                          <pattern id=\"image5\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" height=\"65\" width=\"65\" xlink:href=\"../View/img/maillot/5.png\"></image>
                          </pattern>

                          <pattern id=\"image6\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" height=\"25\" width=\"25\" xlink:href=\"../View/img/logo-ballon.png\"></image>
                          </pattern>


                          <pattern id=\"arrow_1\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" height=\"70\" width=\"70\" xlink:href=\"../View/img/logo-arrow.png\"></image>
                          </pattern>
                          <pattern id=\"arrow_2\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" height=\"70\" width=\"70\" xlink:href=\"../View/img/logo-arrow.png\"></image>
                          </pattern>
                          <pattern id=\"arrow_3\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" height=\"70\" width=\"70\" xlink:href=\"../View/img/logo-arrow.png\"></image>
                          </pattern>
                          <pattern id=\"arrow_4\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" height=\"70\" width=\"70\" xlink:href=\"../View/img/logo-arrow.png\"></image>
                          </pattern>
                          <pattern id=\"arrow_5\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" height=\"70\" width=\"70\" xlink:href=\"../View/img/logo-arrow.png\"></image>
                          </pattern>


                          <pattern id=\"arrow_1_p\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" height=\"70\" width=\"70\" xlink:href=\"../View/img/logo-arrow-pointie.png\"></image>
                          </pattern>
                          <pattern id=\"arrow_2_p\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" height=\"70\" width=\"70\" xlink:href=\"../View/img/logo-arrow-pointie.png\"></image>
                          </pattern>
                          <pattern id=\"arrow_3_p\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" height=\"70\" width=\"70\" xlink:href=\"../View/img/logo-arrow-pointie.png\"></image>
                          </pattern>
                          <pattern id=\"arrow_4_p\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" height=\"70\" width=\"70\" xlink:href=\"../View/img/logo-arrow-pointie.png\"></image>
                          </pattern>
                          <pattern id=\"arrow_5_p\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" height=\"70\" width=\"70\" xlink:href=\"../View/img/logo-arrow-pointie.png\"></image>
                          </pattern>

                          <pattern id=\"raquette_img\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" width=\"70\" height=\"50\" xlink:href=\"../View/img/logo-raquette.png\"></image>
                          </pattern>
                          <pattern id=\"raquette_img_2\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" width=\"70\" height=\"50\" xlink:href=\"../View/img/logo-raquette.png\"></image>
                          </pattern>
                          <pattern id=\"raquette_img_3\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" width=\"70\" height=\"50\" xlink:href=\"../View/img/logo-raquette.png\"></image>
                          </pattern>

                          <pattern id=\"bloquer_img\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" width=\"70\" height=\"50\" xlink:href=\"../View/img/logo-bloquer.png\"></image>
                          </pattern>
                          <pattern id=\"bloquer_img_2\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" width=\"70\" height=\"50\" xlink:href=\"../View/img/logo-bloquer.png\"></image>
                          </pattern>
                          <pattern id=\"bloquer_img_3\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" width=\"70\" height=\"50\" xlink:href=\"../View/img/logo-bloquer.png\"></image>
                          </pattern>

                          <pattern id=\"drive_img\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" width=\"70\" height=\"50\" xlink:href=\"../View/img/logo-arrow-drive.png\"></image>
                          </pattern>
                          <pattern id=\"drive_img_2\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" width=\"70\" height=\"50\" xlink:href=\"../View/img/logo-arrow-drive.png\"></image>
                          </pattern>
                          <pattern id=\"drive_img_3\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" width=\"70\" height=\"50\" xlink:href=\"../View/img/logo-arrow-drive.png\"></image>
                          </pattern>

                          <pattern id=\"course_img\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" width=\"70\" height=\"50\" xlink:href=\"../View/img/logo-arrow-course.png\"></image>
                          </pattern>
                          <pattern id=\"course_img_2\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" width=\"70\" height=\"50\" xlink:href=\"../View/img/logo-arrow-course.png\"></image>
                          </pattern>
                          <pattern id=\"course_img_3\" height=\"5\" width=\"5\">
                            <image x=\"0\" y=\"0\" width=\"70\" height=\"50\" xlink:href=\"../View/img/logo-arrow-course.png\"></image>
                        </defs>

                        <rect x=\"0\" y=\"0\" width=\"750\" height=\"535\" stroke=\"#0E0E0E\" fill=\"url(#image)\" />

                        <ellipse id=\"joueuse_1\" cx=\"0\" cy=\"0\" rx=\"35\" ry=\"37\" transform=\" ". $this->tab_schema[$n][1] ." \" stroke-width=\"1\" stroke=\"#\" fill=\"url(#image1)\" />
                        <ellipse id=\"joueuse_2\" cx=\"0\" cy=\"0\" rx=\"35\" ry=\"37\" transform=\" ". $this->tab_schema[$n][2] ." \" stroke-width=\"1\" stroke=\"#\" fill=\"url(#image2)\" />
                        <ellipse id=\"joueuse_3\" cx=\"0\" cy=\"0\" rx=\"35\" ry=\"37\" transform=\" ". $this->tab_schema[$n][3] ." \" stroke-width=\"1\" stroke=\"#\" fill=\"url(#image3)\" />
                        <ellipse id=\"joueuse_4\" cx=\"0\" cy=\"0\" rx=\"35\" ry=\"37\" transform=\" ". $this->tab_schema[$n][4] ." \" stroke-width=\"1\" stroke=\"#\" fill=\"url(#image4)\" />
                        <ellipse id=\"joueuse_5\" cx=\"0\" cy=\"0\" rx=\"35\" ry=\"37\" transform=\" ". $this->tab_schema[$n][5] ." \" stroke-width=\"1\" stroke=\"#\" fill=\"url(#image5)\" />

                        <ellipse id=\"ballon\" cx=\"0\" cy=\"0\" rx=\"12.5\" ry=\"12.5\" transform=\" ". $this->tab_schema[$n][6] ." \" stroke-width=\"1\" stroke=\"#0E0E0E\" fill=\"url(#image6)\" />

                        <rect id=\"arrow\"    x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][7] ." \"    stroke-width=\"1\" stroke=\"\" fill=\"url(#arrow_1)\" />
                        <rect id=\"arrow_2\"  x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][8] ." \"  stroke-width=\"1\" stroke=\"\" fill=\"url(#arrow_2)\" />
                        <rect id=\"arrow_3\"  x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][9] ." \"  stroke-width=\"1\" stroke=\"\" fill=\"url(#arrow_3)\" />
                        <rect id=\"arrow_4\"  x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][10] ." \" stroke-width=\"1\" stroke=\"\" fill=\"url(#arrow_4)\" />
                        <rect id=\"arrow_5\"  x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][11] ." \" stroke-width=\"1\" stroke=\"\" fill=\"url(#arrow_5)\" />

                        <rect id=\"arrow_p1\"  x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][12] ." \" stroke-width=\"1\" stroke=\"\" fill=\"url(#arrow_1_p)\" />
                        <rect id=\"arrow_p2\"  x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][13] ." \" stroke-width=\"1\" stroke=\"\" fill=\"url(#arrow_2_p)\" />
                        <rect id=\"arrow_p3\"  x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][14] ." \" stroke-width=\"1\" stroke=\"\" fill=\"url(#arrow_3_p)\" />
                        <rect id=\"arrow_p4\"  x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][15] ." \" stroke-width=\"1\" stroke=\"\" fill=\"url(#arrow_4_p)\" />
                        <rect id=\"arrow_p5\"  x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][16] ." \" stroke-width=\"1\" stroke=\"\" fill=\"url(#arrow_5_p)\" />

                        <rect id=\"raquette\"    x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][17] ." \" stroke-width=\"1\" stroke=\"\" fill=\"url(#raquette_img)\" />
                        <rect id=\"raquette_2\"  x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][18] ." \" stroke-width=\"1\" stroke=\"\" fill=\"url(#raquette_img_2)\" />
                        <rect id=\"raquette_3\"  x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][19] ." \" stroke-width=\"1\" stroke=\"\" fill=\"url(#raquette_img_3)\" />

                        <rect id=\"bloquer\"    x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][20] ." \" stroke-width=\"1\" stroke=\"\" fill=\"url(#bloquer_img)\" />
                        <rect id=\"bloquer_2\"  x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][21] ." \" stroke-width=\"1\" stroke=\"\" fill=\"url(#bloquer_img_2)\" />
                        <rect id=\"bloquer_3\"  x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][22] ." \" stroke-width=\"1\" stroke=\"\" fill=\"url(#bloquer_img_3)\" />

                        <rect id=\"drive\"    x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][23] ." \" stroke-width=\"1\" stroke=\"\" fill=\"url(#drive_img)\" />
                        <rect id=\"drive_2\"  x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][24] ." \" stroke-width=\"1\" stroke=\"\" fill=\"url(#drive_img_2)\" />
                        <rect id=\"drive_3\"  x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][25] ." \" stroke-width=\"1\" stroke=\"\" fill=\"url(#drive_img_3)\" />

                        <rect id=\"course\"    x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][26] ." \" stroke-width=\"1\" stroke=\"\" fill=\"url(#course_img)\" />
                        <rect id=\"course_2\"  x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][27] ." \" stroke-width=\"1\" stroke=\"\" fill=\"url(#course_img_2)\" />
                        <rect id=\"course_3\"  x=\"0\"  y=\"0\" width=\"70\" height=\"50\" transform=\" ". $this->tab_schema[$n][28] ." \" stroke-width=\"1\" stroke=\"\" fill=\"url(#course_img_3)\" />
                      </g>
                    </svg>
                  </div>
                </div> <br> <br>
              ";
          }
        echo "</div>";
    ?>

    <?php include("../View/menu.view.php") ?>
  </body>
</html>
