<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="utf-8">

  <title>Dissiner schema</title>
  <script src="https://code.jquery.com/jquery-3.5.0.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=0.65, maximum-scale=0.65, user-scalable=0">
  <style media="screen">
    html{
      font-family: Helvetica,Arial,sans-serif;
      background: linear-gradient(white, #efefef);
      height: 100%;
    }

    @media only screen and (max-width:1000px) {
      svg {
        /* zoom:140%; */
      }

      .btn{
        text-align: center;
      }

      .titre{
        justify-content: center;
      }
    }

    a {
      text-decoration: none;
      color: black;
    }

    button {
      margin-left: 100px;
    }

    .btn-add > input{
      background-color: #DAD9D9;
      border : solid 0.5em #C82619;
      border-radius: 10px;
      color: black;
      border: none;
      padding: 20px 30px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
    }

    .titre{
      display: flex;
    }

    .titre > h2{
      margin: 0px;
      padding-right: 30px;
    }
  </style>
</head>

<body>
  <form>
  <div class="titre">
    <h2>Entrer un nom au schéma : </h2>
    <input type="text" onkeypress="refuserToucheEntree(event);" id="titre_schema" name="titre_schema" value="<?= $_GET["titre_schema"] ?>">
  </div> <br>

  <div>La cible verrouillée : <strong id="verrou"> </strong> </div>


  <div class="svg">
    <svg id="test_du_svg" width="535" height="750">
      <script>

      </script>

      <g id="g" onmousemove="move(event)" onmousedown="cliquer_pc(event)" onclick="cliquer_pc(event)" onmouseup="appui = false">
        <defs>
          <pattern id="image" patternUnits="userSpaceOnUse" height="750" width="500">
            <image x="0" y="0" height="750" width="500" xlink:href="../View/img/basket.png"></image>
          </pattern>

          <pattern id="image1" height="5" width="5">
            <image x="0" y="0" height="65" width="65" xlink:href="../View/img/maillot/1.png"></image>
          </pattern>
          <pattern id="image2" height="5" width="5">
            <image x="0" y="0" height="65" width="65" xlink:href="../View/img/maillot/2.png"></image>
          </pattern>
          <pattern id="image3" height="5" width="5">
            <image x="0" y="0" height="65" width="65" xlink:href="../View/img/maillot/3.png"></image>
          </pattern>
          <pattern id="image4" height="5" width="5">
            <image x="0" y="0" height="65" width="65" xlink:href="../View/img/maillot/4.png"></image>
          </pattern>
          <pattern id="image5" height="5" width="5">
            <image x="0" y="0" height="65" width="65" xlink:href="../View/img/maillot/5.png"></image>
          </pattern>

          <pattern id="image6" height="5" width="5">
            <image x="0" y="0" height="25" width="25" xlink:href="../View/img/logo-ballon.png"></image>
          </pattern>

          <pattern id="arrow_1.1" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow.png"></image>
          </pattern>
          <pattern id="arrow_2.1" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow.png"></image>
          </pattern>
          <pattern id="arrow_3.1" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow.png"></image>
          </pattern>
          <pattern id="arrow_4.1" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow.png"></image>
          </pattern>
          <pattern id="arrow_5.1" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow.png"></image>
          </pattern>

          <pattern id="arrow_1.1_p" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-pointie.png"></image>
          </pattern>
          <pattern id="arrow_2.1_p" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-pointie.png"></image>
          </pattern>
          <pattern id="arrow_3.1_p" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-pointie.png"></image>
          </pattern>
          <pattern id="arrow_4.1_p" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-pointie.png"></image>
          </pattern>
          <pattern id="arrow_5.1_p" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-pointie.png"></image>
          </pattern>

          <pattern id="raquette_img" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-raquette.png"></image>
          </pattern>
          <pattern id="raquette_img_2" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-raquette.png"></image>
          </pattern>
          <pattern id="raquette_img_3" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-raquette.png"></image>
          </pattern>

          <pattern id="bloquer_img" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-bloquer.png"></image>
          </pattern>
          <pattern id="bloquer_img_2" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-bloquer.png"></image>
          </pattern>
          <pattern id="bloquer_img_3" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-bloquer.png"></image>
          </pattern>

          <pattern id="drive_img" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-drive.png"></image>
          </pattern>
          <pattern id="drive_img_2" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-drive.png"></image>
          </pattern>
          <pattern id="drive_img_3" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-drive.png"></image>
          </pattern>

          <pattern id="course_img" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-course.png"></image>
          </pattern>
          <pattern id="course_img_2" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-course.png"></image>
          </pattern>
          <pattern id="course_img_3" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-course.png"></image>
          </pattern>
        </defs>

        <!-- Rect  -->
        <rect x="0" y="0" width="535" height="750" stroke="#0E0E0E" fill="url(#image)" />

        <!-- Forme signifiant les joueuses -->
        <rect id="course_1"    x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[7] ?>" stroke-width="1" stroke="" fill="url(#arrow_1.1)" />
        <rect id="course_2"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[8] ?>" stroke-width="1" stroke="" fill="url(#arrow_2.1)" />
        <rect id="course_3"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[9] ?>" stroke-width="1" stroke="" fill="url(#arrow_3.1)" />
        <rect id="course_4"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[10] ?>" stroke-width="1" stroke="" fill="url(#arrow_4.1)" />
        <rect id="course_1"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[11] ?>" stroke-width="1" stroke="" fill="url(#arrow_5.1)" />

        <rect id="passe_1"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[12] ?>" stroke-width="1" stroke="" fill="url(#arrow_1.1_p)" />
        <rect id="passe_2"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[13] ?>" stroke-width="1" stroke="" fill="url(#arrow_2.1_p)" />
        <rect id="passe_3"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[14] ?>" stroke-width="1" stroke="" fill="url(#arrow_3.1_p)" />
        <rect id="passe_4"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[15] ?>" stroke-width="1" stroke="" fill="url(#arrow_4.1_p)" />
        <rect id="passe_5"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[16] ?>" stroke-width="1" stroke="" fill="url(#arrow_5.1_p)" />

        <rect id="raquette_1"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[17] ?>" stroke-width="1" stroke="" fill="url(#raquette_img)" />
        <rect id="raquette_2"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[18] ?>" stroke-width="1" stroke="" fill="url(#raquette_img_2)" />
        <rect id="raquette_3"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[19] ?>" stroke-width="1" stroke="" fill="url(#raquette_img_3)" />

        <rect id="bloquer_1"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[20] ?>" stroke-width="1" stroke="" fill="url(#bloquer_img)" />
        <rect id="bloquer_2"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[21] ?>" stroke-width="1" stroke="" fill="url(#bloquer_img_2)" />
        <rect id="bloquer_3"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[22] ?>" stroke-width="1" stroke="" fill="url(#bloquer_img_3)" />

        <rect id="drive_1"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[23] ?>" stroke-width="1" stroke="" fill="url(#drive_img)" />
        <rect id="drive_2"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[24] ?>" stroke-width="1" stroke="" fill="url(#drive_img_2)" />
        <rect id="drive_3"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[25] ?>" stroke-width="1" stroke="" fill="url(#drive_img_3)" />

        <rect id="course_ecran_1"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[26] ?>" stroke-width="1" stroke="" fill="url(#course_img)" />
        <rect id="course_ecran_2"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[27] ?>" stroke-width="1" stroke="" fill="url(#course_img_2)" />
        <rect id="course_ecran_3"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[28] ?>" stroke-width="1" stroke="" fill="url(#course_img_3)" />

        <ellipse id="joueuse_1" cx="0" cy="0" rx="35" ry="37" transform="<?= $this->tab_schema[1] ?>" stroke-width="1" stroke="" fill="url(#image1)" />
        <ellipse id="joueuse_2" cx="0" cy="0" rx="35" ry="37" transform="<?= $this->tab_schema[2] ?>" stroke-width="1" stroke="" fill="url(#image2)"  />
        <ellipse id="joueuse_3" cx="0" cy="0" rx="35" ry="37" transform="<?= $this->tab_schema[3] ?>" stroke-width="1" stroke="" fill="url(#image3)"  />
        <ellipse id="joueuse_4" cx="0" cy="0" rx="35" ry="37" transform="<?= $this->tab_schema[4] ?>" stroke-width="1" stroke="" fill="url(#image4)"  />
        <ellipse id="joueuse_5" cx="0" cy="0" rx="35" ry="37" transform="<?= $this->tab_schema[5] ?>" stroke-width="1" stroke="" fill="url(#image5)"  />

        <ellipse id="ballon"    cx="0" cy="0" rx="12.5" ry="12.5" transform="<?= $this->tab_schema[6] ?>" stroke-width="1" stroke="#0E0E0E" fill="url(#image6)"  />
      </g>

      <script type="text/javascript">
      // -------------------------------------------------------------------------      DECLARATION DES VARIABLE      -------------------------------------------------------------------------
              var appui = false;
              var cible = "";
              var xd2 = 0;
              var yd2 = 0;
              var xd1 = 0;
              var yd1 = 0;
              var coeffs = new Array();

              var test_1;
              var test_2;

              var nom_fichier = <?php echo json_encode($this->nom_fichier); ?>;
              var nom_schema = <?php echo json_encode($this->nom_schema); ?>;

              // joueuses
              var matrice_1 = <?php echo json_encode($this->tab_schema[1]); ?>;
              var matrice_2 = <?php echo json_encode($this->tab_schema[2]); ?>;
              var matrice_3 = <?php echo json_encode($this->tab_schema[3]); ?>;
              var matrice_4 = <?php echo json_encode($this->tab_schema[4]); ?>;
              var matrice_5 = <?php echo json_encode($this->tab_schema[5]); ?>;
              var matrice_6 = <?php echo json_encode($this->tab_schema[6]); ?>;

              // felche
              var matrice_7 = <?php echo json_encode($this->tab_schema[7]); ?>;
              var matrice_8 = <?php echo json_encode($this->tab_schema[8]); ?>;
              var matrice_9 = <?php echo json_encode($this->tab_schema[9]); ?>;
              var matrice_10 = <?php echo json_encode($this->tab_schema[10]); ?>;
              var matrice_11 = <?php echo json_encode($this->tab_schema[11]); ?>;

              // felche pointillé
              var matrice_12 = <?php echo json_encode($this->tab_schema[12]); ?>;
              var matrice_13 = <?php echo json_encode($this->tab_schema[13]); ?>;
              var matrice_14 = <?php echo json_encode($this->tab_schema[14]); ?>;
              var matrice_15 = <?php echo json_encode($this->tab_schema[15]); ?>;
              var matrice_16 = <?php echo json_encode($this->tab_schema[16]); ?>;

              // autre objet
              var matrice_17 = <?php echo json_encode($this->tab_schema[17]); ?>;
              var matrice_17_2 = <?php echo json_encode($this->tab_schema[18]); ?>;
              var matrice_17_3 = <?php echo json_encode($this->tab_schema[19]); ?>;

              var matrice_18 = <?php echo json_encode($this->tab_schema[20]); ?>;
              var matrice_18_2 = <?php echo json_encode($this->tab_schema[21]); ?>;
              var matrice_18_3 = <?php echo json_encode($this->tab_schema[22]); ?>;

              var matrice_19 = <?php echo json_encode($this->tab_schema[23]); ?>;
              var matrice_19_2 = <?php echo json_encode($this->tab_schema[24]); ?>;
              var matrice_19_3 = <?php echo json_encode($this->tab_schema[25]); ?>;

              var matrice_20 = <?php echo json_encode($this->tab_schema[26]); ?>;
              var matrice_20_2 = <?php echo json_encode($this->tab_schema[27]); ?>;
              var matrice_20_3 = <?php echo json_encode($this->tab_schema[28]); ?>;

              // felche
              var strM7 =  matrice_7.split('('); strM7 = strM7[2]; var rotation = strM7.slice(0, -1); rotation = parseInt(rotation, 10);
              var strM8 =  matrice_8.split('('); strM8 = strM8[2]; var rotation_2 = strM8.slice(0, -1); rotation_2 = parseInt(rotation_2, 10);
              var strM9 =  matrice_9.split('('); strM9 = strM9[2]; var rotation_3 = strM9.slice(0, -1); rotation_3 = parseInt(rotation_3, 10);
              var strM10 =  matrice_10.split('('); strM10 = strM10[2]; var rotation_4 = strM10.slice(0, -1); rotation_4 = parseInt(rotation_4, 10);
              var strM11 =  matrice_11.split('('); strM11 = strM11[2]; var rotation_5 = strM11.slice(0, -1); rotation_5 = parseInt(rotation_5, 10);

              // felche pointillé
              var strM12 =  matrice_12.split('('); strM12 = strM12[2]; var rotation_p1 = strM12.slice(0, -1); rotation_p1 = parseInt(rotation_p1, 10);
              var strM13 =  matrice_13.split('('); strM13 = strM13[2]; var rotation_p2 = strM13.slice(0, -1); rotation_p2 = parseInt(rotation_p2, 10);
              var strM14 =  matrice_14.split('('); strM14 = strM14[2]; var rotation_p3 = strM14.slice(0, -1); rotation_p3 = parseInt(rotation_p3, 10);
              var strM15 =  matrice_15.split('('); strM15 = strM15[2]; var rotation_p4 = strM15.slice(0, -1); rotation_p4 = parseInt(rotation_p4, 10);
              var strM16 =  matrice_16.split('('); strM16 = strM16[2]; var rotation_p5 = strM16.slice(0, -1); rotation_p5 = parseInt(rotation_p5, 10);

              // autre objet
              var strM17 =  matrice_17.split('('); strM17 = strM17[2]; var rotation_raquette = strM17.slice(0, -1); rotation_raquette = parseInt(rotation_raquette, 10);
              var strM17_2 =  matrice_17_2.split('('); strM17_2 = strM17_2[2]; var rotation_raquette_2 = strM17_2.slice(0, -1); rotation_raquette_2 = parseInt(rotation_raquette_2, 10);
              var strM17_3 =  matrice_17_3.split('('); strM17_3 = strM17_3[2]; var rotation_raquette_3 = strM17_3.slice(0, -1); rotation_raquette_3 = parseInt(rotation_raquette_3, 10);

              var strM18 =  matrice_18.split('('); strM18 = strM18[2]; var rotation_bloquer = strM18.slice(0, -1); rotation_bloquer = parseInt(rotation_bloquer, 10);
              var strM18_2 =  matrice_18_2.split('('); strM18_2 = strM18_2[2]; var rotation_bloquer_2 = strM18_2.slice(0, -1); rotation_bloquer_2 = parseInt(rotation_bloquer_2, 10);
              var strM18_3 =  matrice_18_3.split('('); strM18_3 = strM18_3[2]; var rotation_bloquer_3 = strM18_3.slice(0, -1); rotation_bloquer_3 = parseInt(rotation_bloquer_3, 10);

              var strM19 =  matrice_19.split('('); strM19 = strM19[2]; var rotation_drive = strM19.slice(0, -1); rotation_drive = parseInt(rotation_drive, 10);
              var strM19_2 =  matrice_19_2.split('('); strM19_2 = strM19_2[2]; var rotation_drive_2 = strM19_2.slice(0, -1); rotation_drive_2 = parseInt(rotation_drive_2, 10);
              var strM19_3 =  matrice_19_3.split('('); strM19_3 = strM19_3[2]; var rotation_drive_3 = strM19_3.slice(0, -1); rotation_drive_3 = parseInt(rotation_drive_3, 10);

              var strM20 =  matrice_20.split('('); strM20 = strM20[2]; var rotation_course = strM20.slice(0, -1); rotation_course = parseInt(rotation_course, 10);
              var strM20_2 =  matrice_20_2.split('('); strM20_2 = strM20_2[2]; var rotation_course_2 = strM20.slice(0, -1); rotation_course_2 = parseInt(rotation_course_2, 10);
              var strM20_3 =  matrice_20_3.split('('); strM20_3 = strM20_3[2]; var rotation_course_3 = strM20.slice(0, -1); rotation_course_3 = parseInt(rotation_course_3, 10);

              var table_objet = [
                ["joueuse_1", matrice_1],
                ["joueuse_2", matrice_2],
                ["joueuse_3", matrice_3],
                ["joueuse_4", matrice_4],
                ["joueuse_5", matrice_5],

                ["ballon", matrice_6],

                ["course_1", matrice_7],
                ["course_2", matrice_8],
                ["course_3", matrice_9],
                ["course_4", matrice_10],
                ["course_1", matrice_11],

                ["passe_1", matrice_12],
                ["passe_2", matrice_13],
                ["passe_3", matrice_14],
                ["passe_4", matrice_15],
                ["passe_5", matrice_16],

                ["raquette_1", matrice_17],
                ["raquette_2", matrice_17_2],
                ["raquette_3", matrice_17_3],

                ["bloquer_1", matrice_18],
                ["bloquer_2", matrice_18_2],
                ["bloquer_3", matrice_18_3],

                ["drive_1", matrice_19],
                ["drive_2", matrice_19_2],
                ["drive_3", matrice_19_3],

                ["course_ecran_1", matrice_20],
                ["course_ecran_2", matrice_20_2],
                ["course_ecran_3", matrice_20_3]
              ];

              var table_temporaire = new Array();
              var chaine;

              var xm = 0;
              var ym = 0;

              var mobile = 0;

              var elm_verrou = document.getElementById('verrou');
              elm_verrou.innerHTML = "Rien de selectionné !";

      // -------------------------------------------------------------------------      FUNCTION MAJ LA MATRICE      -------------------------------------------------------------------------
              function arrowMAJ(){ // appeler par la fonction move()
                  table_temporaire.push(cible);

                  if(cible == "course_1") {
                      document.getElementById("course_1").style.transform = test_2 + " rotate(" + rotation + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation + ")");
                  } else if(cible == "course_2") {
                      document.getElementById("course_2").style.transform = test_2 + " rotate(" + rotation_2 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_2 + ")");
                  } else if(cible == "course_3") {
                      document.getElementById("course_3").style.transform = test_2 + " rotate(" + rotation_3 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_3 + ")");
                  } else if(cible == "course_4") {
                      document.getElementById("course_4").style.transform = test_2 + " rotate(" + rotation_4 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_4 + ")");
                  } else if(cible == "course_1") {
                      document.getElementById("course_1").style.transform = test_2 + " rotate(" + rotation_5 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_5 + ")");
                  }

                  if(cible == "passe_1") {
                      document.getElementById("passe_1").style.transform = test_2 + " rotate(" + rotation_p1 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_p1 + ")");
                  } else if(cible == "passe_2") {
                      document.getElementById("passe_2").style.transform = test_2 + " rotate(" + rotation_p2 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_p2 + ")");
                  } else if(cible == "passe_3") {
                      document.getElementById("passe_3").style.transform = test_2 + " rotate(" + rotation_p3 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_p3 + ")");
                  } else if(cible == "passe_4") {
                      document.getElementById("passe_4").style.transform = test_2 + " rotate(" + rotation_p4 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_p4 + ")");
                  } else if(cible == "passe_5") {
                      document.getElementById("passe_5").style.transform = test_2 + " rotate(" + rotation_p5 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_p5 + ")");
                  }

                  if(cible == "raquette_1") {
                      document.getElementById("raquette_1").style.transform = test_2 + " rotate(" + rotation_raquette + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_raquette + ")");
                  } else if (cible == "raquette_2") {
                      document.getElementById("raquette_2").style.transform = test_2 + " rotate(" + rotation_raquette_2 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_raquette_2 + ")");
                  } else if (cible == "raquette_3") {
                      document.getElementById("raquette_3").style.transform = test_2 + " rotate(" + rotation_raquette_3 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_raquette_3 + ")");
                  }

                  else if(cible == "bloquer_1") {
                      document.getElementById("bloquer_1").style.transform = test_2 + " rotate(" + rotation_bloquer + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_bloquer + ")");
                  } else if(cible == "bloquer_2") {
                      document.getElementById("bloquer_2").style.transform = test_2 + " rotate(" + rotation_bloquer_2 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_bloquer_2 + ")");
                  } else if(cible == "bloquer_3") {
                      document.getElementById("bloquer_3").style.transform = test_2 + " rotate(" + rotation_bloquer_3 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_bloquer_3 + ")");
                  }

                  else if(cible == "drive_1") {
                      document.getElementById("drive_1").style.transform = test_2 + " rotate(" + rotation_drive + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_drive + ")");
                  } else if(cible == "drive_2") {
                      document.getElementById("drive_2").style.transform = test_2 + " rotate(" + rotation_drive_2 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_drive_2 + ")");
                  } else if(cible == "drive_3") {
                      document.getElementById("drive_3").style.transform = test_2 + " rotate(" + rotation_drive_3 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_drive_3 + ")");
                  }

                  else if(cible == "course_ecran_1") {
                      document.getElementById("course_ecran_1").style.transform = test_2 + " rotate(" + rotation_course + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_course + ")");
                  } else if(cible == "course_ecran_2") {
                      document.getElementById("course_ecran_2").style.transform = test_2 + " rotate(" + rotation_course_2 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_course_2 + ")");
                  } else if(cible == "course_ecran_3") {
                      document.getElementById("course_ecran_3").style.transform = test_2 + " rotate(" + rotation_course_3 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_course_3 + ")");
                  }
              }
      // -------------------------------------------------------------------------      FUNCTION  MAJ LA ROTATION      -------------------------------------------------------------------------
              function rotationMAJ() { // appeler par la fonction clic()
                  table_temporaire.push(cible);
                  if(cible == "course_1") {
                      if (rotation == 360) { rotation = 0; } else { rotation = rotation + 45; }
                      document.getElementById("course_1").style.transform = test_2 + " rotate(" + rotation + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation + ")");
                  } else if(cible == "course_2") {
                      if (rotation_2 == 360) { rotation_2 = 0; } else { rotation_2 = rotation_2 + 45; }
                      document.getElementById("course_2").style.transform = test_2 + " rotate(" + rotation_2 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_2 + ")");
                  } else if(cible == "course_3") {
                      if (rotation_3 == 360) { rotation_3 = 0; } else { rotation_3 = rotation_3 + 45; }
                      document.getElementById("course_3").style.transform = test_2 + " rotate(" + rotation_3 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_3 + ")");
                  } else if(cible == "course_4") {
                      if (rotation_4 == 360) { rotation_4 = 0; } else { rotation_4 = rotation_4 + 45; }
                      document.getElementById("course_4").style.transform = test_2 + " rotate(" + rotation_4 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_4 + ")");
                  } else if(cible == "course_1") {
                      if (rotation_5 == 360) { rotation_5 = 0; } else { rotation_5 = rotation_5 + 45; }
                      document.getElementById("course_1").style.transform = test_2 + " rotate(" + rotation_5 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_5 + ")");
                  }

                  if(cible == "passe_1") {
                      if (rotation_p1 == 360) { rotation_p1 = 0; } else { rotation_p1 = rotation_p1 + 45; }
                      document.getElementById("passe_1").style.transform = test_2 + " rotate(" + rotation_p1 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_p1 + ")");
                  } else if(cible == "passe_2") {
                      if (rotation_p2 == 360) { rotation_p2 = 0; } else { rotation_p2 = rotation_p2 + 45; }
                      document.getElementById("passe_2").style.transform = test_2 + " rotate(" + rotation_p2 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_p2 + ")");
                  } else if(cible == "passe_3") {
                      if (rotation_p3 == 360) { rotation_p3 = 0; } else { rotation_p3 = rotation_p3 + 45; }
                      document.getElementById("passe_3").style.transform = test_2 + " rotate(" + rotation_p3 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_p3 + ")");
                  } else if(cible == "passe_4") {
                      if (rotation_p4 == 360) { rotation_p4 = 0; } else { rotation_p4 = rotation_p4 + 45; }
                      document.getElementById("passe_4").style.transform = test_2 + " rotate(" + rotation_p4 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_p4 + ")");
                  } else if(cible == "passe_5") {
                      if (rotation_p5 == 360) { rotation_p5 = 0; } else { rotation_p5 = rotation_p5 + 45; }
                      document.getElementById("passe_5").style.transform = test_2 + " rotate(" + rotation_p5 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_p5 + ")");
                  }

                  if(cible == "raquette_1") {
                      if (rotation_raquette == 360) { rotation_raquette = 0; } else { rotation_raquette = rotation_raquette + 45; }
                      document.getElementById("raquette_1").style.transform = test_2 + " rotate(" + rotation_raquette + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_raquette + ")");
                  } else if(cible == "raquette_2") {
                      if (rotation_raquette_2 == 360) { rotation_raquette_2 = 0; } else { rotation_raquette_2 = rotation_raquette_2 + 45; }
                      document.getElementById("raquette_2").style.transform = test_2 + " rotate(" + rotation_raquette_2 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_raquette_2 + ")");
                  } else if(cible == "raquette_3") {
                      if (rotation_raquette_3 == 360) { rotation_raquette_3 = 0; } else { rotation_raquette_3 = rotation_raquette_3 + 45; }
                      document.getElementById("raquette_3").style.transform = test_2 + " rotate(" + rotation_raquette_3 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_raquette_3 + ")");
                  }

                  else if(cible == "bloquer_1") {
                      if (rotation_bloquer == 360) { rotation_bloquer = 0; } else { rotation_bloquer = rotation_bloquer + 45; }
                      document.getElementById("bloquer_1").style.transform = test_2 + " rotate(" + rotation_bloquer + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_bloquer + ")");
                  } else if(cible == "bloquer_2") {
                      if (rotation_bloquer_2 == 360) { rotation_bloquer_2 = 0; } else { rotation_bloquer_2 = rotation_bloquer_2 + 45; }
                      document.getElementById("bloquer_2").style.transform = test_2 + " rotate(" + rotation_bloquer_2 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_bloquer_2 + ")");
                  } else if(cible == "bloquer_3") {
                      if (rotation_bloquer_3 == 360) { rotation_bloquer_3 = 0; } else { rotation_bloquer_3 = rotation_bloquer_3 + 45; }
                      document.getElementById("bloquer_3").style.transform = test_2 + " rotate(" + rotation_bloquer_3 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_bloquer_3 + ")");
                  }

                  else if(cible == "drive_1") {
                      if (rotation_drive == 360) { rotation_drive = 0; } else { rotation_drive = rotation_drive + 45; }
                      document.getElementById("drive_1").style.transform = test_2 + " rotate(" + rotation_drive + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_drive + ")");
                  } else if(cible == "drive_2") {
                      if (rotation_drive_2 == 360) { rotation_drive_2 = 0; } else { rotation_drive_2 = rotation_drive_2 + 45; }
                      document.getElementById("drive_2").style.transform = test_2 + " rotate(" + rotation_drive_2 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_drive_2 + ")");
                  } else if(cible == "drive_3") {
                      if (rotation_drive_3 == 360) { rotation_drive_3 = 0; } else { rotation_drive_3 = rotation_drive_3 + 45; }
                      document.getElementById("drive_3").style.transform = test_2 + " rotate(" + rotation_drive_3 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_drive_3 + ")");
                  }

                  else if(cible == "course_ecran_1") {
                      if (rotation_course == 360) { rotation_course = 0; } else { rotation_course = rotation_course + 45; }
                      document.getElementById("course_ecran_1").style.transform = test_2 + " rotate(" + rotation_course + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_course + ")");
                  } else if(cible == "course_ecran_2") {
                      if (rotation_course_2 == 360) { rotation_course_2 = 0; } else { rotation_course_2 = rotation_course_2 + 45; }
                      document.getElementById("course_ecran_2").style.transform = test_2 + " rotate(" + rotation_course_2 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_course_2 + ")");
                  } else if(cible == "course_ecran_3") {
                      if (rotation_course_3 == 360) { rotation_course_3 = 0; } else { rotation_course_3 = rotation_course_3 + 45; }
                      document.getElementById("course_ecran_3").style.transform = test_2 + " rotate(" + rotation_course_3 + "deg)";
                      table_temporaire.push(chaine + "rotate(" + rotation_course_3 + ")");
                  }
              }


      // -------------------------------------------------------------------------      FUNCTION MAJ LORS DEPLACEMENT      -------------------------------------------------------------------------
              function move(event) {
                // coordonée la souris (ou elle pointe)
                if (cible != null && cible != '') {
                  document.querySelector("#"+cible).addEventListener('touchmove', function(event) {
                    xm = (event.touches[0].clientX);
                    ym = (event.touches[0].clientY);

                    mobile = 1;

                  }, false);

                  xm = event.clientX;
                  ym = event.clientY;

                  if (!appui) {
                    return;
                  }

                  if ((xm <= 0) || (xm >= 535) || (ym <= 0) || (ym >= 750)) {
                    appui = false;
                    mobile = 1;
                  }

                  if ((event && (event.which == 1 || event.button == 2 )) || mobile == 1) {
                    svgdoc = event.target.ownerDocument;
                    // coeffs[4] coordonée des X des cercles
                    coeffs[4] = xm + xd1 - xd2;
                    // coeffs[] coordonée des Y des cercles
                    coeffs[5] = ym + yd1 - yd2;


                    if (cible == "joueuse_1" || cible == "joueuse_2" || cible == "joueuse_3" || cible == "joueuse_4" || cible == "joueuse_5" || cible == "ballon" || cible == "course_1"  || cible == "course_2" || cible == "course_3" || cible == "course_4" || cible == "course_1" || cible == "passe_1"  || cible == "passe_2" || cible == "passe_3" || cible == "passe_4" || cible == "passe_5" || cible == "raquette_1" || cible == "raquette_2" || cible == "raquette_3" || cible == "bloquer_1" || cible == "bloquer_2" || cible == "bloquer_3" || cible == "drive_1" || cible == "drive_2" || cible == "drive_3" || cible == "course_ecran_1" || cible == "course_ecran_2" || cible == "course_ecran_3") {
                      if (coeffs[4] < 40) {
                        coeffs[4] = 40; // gauche
                      }
                      if (coeffs[4] > 515) {
                        coeffs[4] = 515; // droite
                      }
                      if (coeffs[5] < 60) {
                        coeffs[5] = 60; // haut
                      }
                      if (coeffs[5] > 720) {
                        coeffs[5] = 720; // bas
                      }
                    }

                    chaine = "matrix(" + coeffs.join(" ") + ")";
                    svgdoc.getElementById(cible).setAttributeNS(null, "transform", chaine);
                  }

                  // seulement pour la fleche
                  if (cible == "course_1"  || cible == "course_2" || cible == "course_3" || cible == "course_4" || cible == "course_1s" || cible == "passe_1"  || cible == "passe_2" || cible == "passe_3" || cible == "passe_4" || cible == "passe_5" || cible == "raquette_1" || cible == "raquette_2" || cible == "raquette_3") {
                    if (event && (event.which == 1 || event.button == 1 )) { // code pour le clic gauche
                      test_1 = chaine.split(' ');
                      test_2 = "matrix(1, 0, 0, 1, " + test_1[4] + ", " + test_1[5];
                      arrowMAJ();
                    }
                  } else if(cible == "bloquer_1" || cible == "bloquer_2" || cible == "bloquer_3" || cible == "drive_1" || cible == "drive_2" || cible == "drive_3" || cible == "course_ecran_1" || cible == "course_ecran_2" || cible == "course_ecran_3") {
                    if (event && (event.which == 1 || event.button == 1 )) { // code pour le clic gauche
                      test_1 = chaine.split(' ');
                      test_2 = "matrix(1, 0, 0, 1, " + test_1[4] + ", " + test_1[5];
                      arrowMAJ();
                    }
                  } else {
                    // on instentie le tableau temporaire
                    table_temporaire.push(cible);
                    table_temporaire.push(chaine);
                  }

                  var objet_exist = false;

                  for (var i = 0; i < table_objet.length; i++) {
                    if (table_objet[i][0] === table_temporaire[0]) {
                     if (table_temporaire !== "" && table_temporaire !== null && table_temporaire !== NaN && table_temporaire !== false && table_temporaire.length > 0 && table_temporaire !== 'undefined') {
                        table_objet[i] = table_temporaire;
                        objet_exist = true;
                      }
                    }
                  }

                  // si l'objet n'existe pas on le rajoute
                  if (objet_exist == false) {
                    if (table_temporaire !== "" && table_temporaire !== null && table_temporaire !== NaN && table_temporaire !== false && table_temporaire.length > 0 && table_temporaire !== 'undefined') {
                      table_objet.push(table_temporaire);
                    }
                  }

                  // on renitialise le tableau temporaire en le mettant vide
                  table_temporaire = [];
                  mobile = 0;

                }
              }
      // -------------------------------------------------------------------------      FUNCTION MAJ LORS CLIC SOURIS      -------------------------------------------------------------------------
              function cliquer_pc(event) {
                // renvoie l'id du cercle choisi
                cible = event.target.getAttributeNS(null, "id");

                if (cible == "joueuse_1" || cible == "joueuse_2" || cible == "joueuse_3" || cible == "joueuse_4" || cible == "joueuse_5" || cible == "ballon" || cible == "course_1"  || cible == "course_2" || cible == "course_3" || cible == "course_4" || cible == "course_1" || cible == "passe_1"  || cible == "passe_2" || cible == "passe_3" || cible == "passe_4" || cible == "passe_5" || cible == "raquette_1" || cible == "raquette_2" || cible == "raquette_3" || cible == "bloquer_1" || cible == "bloquer_2" || cible == "bloquer_3" || cible == "drive_1" || cible == "drive_2" || cible == "drive_3" || cible == "course_ecran_1" || cible == "course_ecran_2" || cible == "course_ecran_3") {
                  appui = true;

                  elm_verrou = document.getElementById('verrou');
                  elm_verrou.innerHTML = cible;

                  var cible_tempo = "#" + cible;

                  document.querySelector(cible_tempo).addEventListener('touchstart', function(event) {
                    xd2 = event.touches[0].clientX;
                    yd2 = event.touches[0].clientY;
                    mobile = 1;
                  }, false);

                  xd2 = event.clientX;
                  yd2 = event.clientY;

                  var transfo = event.target.getAttributeNS(null, "transform");
                  transfo = transfo.substring(7, transfo.length - 1);
                  // Firefox return , as separator in transform attribute
                  if (transfo.indexOf(",") > 0) {
                    coeffs = transfo.split(",");
                  } else {
                    coeffs = transfo.split(" ");
                  }
                  xd1 = parseInt(coeffs[4]);
                  yd1 = parseInt(coeffs[5]);
                } else {
                  elm_verrou = document.getElementById('verrou');
                  elm_verrou.innerHTML = "Rien de selectionné !";
                }

                if (cible == "course_1" || cible == "course_2" || cible == "course_3" || cible == "course_4" || cible == "course_1" || cible == "passe_1" || cible == "passe_2" || cible == "passe_3" || cible == "passe_4" || cible == "passe_5" || cible == "raquette_1" || cible == "raquette_2" || cible == "raquette_3") {
                  if (event && (event.which == 2 || event.button == 4 )) { // code pour le clic molette
                    test_1 = chaine.split(' ');
                    test_2 = "matrix(1, 0, 0, 1, " + test_1[4] + ", " + test_1[5];

                    setTimeout(rotationMAJ, 300);
                  } else if (event && (event.which == 3 || event.button == 2)) { // clic droit
                      var elem = document.getElementById('test_du_svg');
                      elem.addEventListener("contextmenu", function (event) {
                        event.preventDefault();
                      });

                      test_1 = chaine.split(' ');
                      test_2 = "matrix(1, 0, 0, 1, " + test_1[4] + ", " + test_1[5];

                      setTimeout(rotationMAJ, 300);
                  }
                } else if (cible == "bloquer_1" || cible == "bloquer_2" || cible == "bloquer_3" || cible == "drive_1" || cible == "drive_2" || cible == "drive_3" || cible == "course_ecran_1" || cible == "course_ecran_2" || cible == "course_ecran_3") {

                  if (event && (event.which == 2 || event.button == 4 )) { // code pour le clic molette
                    test_1 = chaine.split(' ');
                    test_2 = "matrix(1, 0, 0, 1, " + test_1[4] + ", " + test_1[5];

                    setTimeout(rotationMAJ, 300);
                  } else if (event && (event.which == 3 || event.button == 2)) { // clic droit
                      var elem = document.getElementById('test_du_svg');
                      elem.addEventListener("contextmenu", function (event) {
                        event.preventDefault();
                      });

                      test_1 = chaine.split(' ');
                      test_2 = "matrix(1, 0, 0, 1, " + test_1[4] + ", " + test_1[5];

                      setTimeout(rotationMAJ, 300);
                  }
                }

                if (mobile == 1) {
                  // move(event);
                }
              }
      // -------------------------------------------------------------------------      FUNCTION REDIRECTION      -------------------------------------------------------------------------
              function RedirectionJavascript(){
                document.location.href="../Controler/liste_des_schemas.ctrl.php?nom_systeme=" + nom_fichier;
              }
      // -------------------------------------------------------------------------      FUNCTION ENVOIE DONNEES      -------------------------------------------------------------------------
              function sendData() {
                  var titre_sch = document.getElementById("titre_schema").value;
                  var data = new FormData();
                  // remplacer ici par des valeurs fournise par la page précedente ....
                  // pour 'nom_systeme' et 'nom_schema' ...
                  data.append('nom_systeme', nom_fichier);
                  data.append('nom_schema', nom_schema);
                  data.append('titre_schema', titre_sch);
                  data.append('table_objet', table_objet);

                  var requeteAjax = new XMLHttpRequest();
                  requeteAjax.open('POST', 'recup.php');
                  requeteAjax.send(data);

                  setTimeout('RedirectionJavascript()', 1000);
              }
      // -------------------------------------------------------------------------      FUNCTION RENITIALISE LA MATRICE      -------------------------------------------------------------------------
              function renitialise() {
                  table_objet = [
                    ['joueuse_1', "matrix(1 0 0 1 497 75)"],
                    ["joueuse_2", "matrix(1 0 0 1 497 130)"],
                    ["joueuse_3", "matrix(1 0 0 1 497 185)"],
                    ["joueuse_4", "matrix(1 0 0 1 497 240)"],
                    ["joueuse_5", "matrix(1 0 0 1 497 295)"],
                    ["ballon", "matrix(1 0 0 1 494 350)"],

                    ["course_1", "matrix(1 0 0 1 460 381)rotate(0)"],
                    ["course_2", "matrix(1 0 0 1 460 381)rotate(0)"],
                    ["course_3", "matrix(1 0 0 1 460 381)rotate(0)"],
                    ["course_4", "matrix(1 0 0 1 460 381)rotate(0)"],
                    ["course_1", "matrix(1 0 0 1 460 381)rotate(0)"],

                    ["passe_1", "matrix(1 0 0 1 462 420)rotate(0)"],
                    ["passe_2", "matrix(1 0 0 1 462 420)rotate(0)"],
                    ["passe_3", "matrix(1 0 0 1 462 420)rotate(0)"],
                    ["passe_4", "matrix(1 0 0 1 462 420)rotate(0)"],
                    ["passe_5", "matrix(1 0 0 1 462 420)rotate(0)"],

                    ["raquette_1", "matrix(1 0 0 1 462 460)rotate(0)"],
                    ["raquette_2", "matrix(1 0 0 1 462 460)rotate(0)"],
                    ["raquette_3", "matrix(1 0 0 1 462 460)rotate(0)"],

                    ["bloquer_1", "matrix(1 0 0 1 462 510)rotate(0)"],
                    ["bloquer_2", "matrix(1 0 0 1 462 510)rotate(0)"],
                    ["bloquer_3", "matrix(1 0 0 1 462 510)rotate(0)"],

                    ["drive_1", "matrix(1 0 0 1 462 540)rotate(0)"],
                    ["drive_2", "matrix(1 0 0 1 462 540)rotate(0)"],
                    ["drive_3", "matrix(1 0 0 1 462 540)rotate(0)"],

                    ["course_ecran_1", "matrix(1 0 0 1 462 570)rotate(0)"],
                    ["course_ecran_2", "matrix(1 0 0 1 462 570)rotate(0)"],
                    ["course_ecran_3", "matrix(1 0 0 1 462 570)rotate(0)"]
                  ];
                  location.reload(true);
              }
      // -------------------------------------------------------------------------      FUNCTION ENLEVER RETOUR CHARIOT DANS LE INPUT      -------------------------------------------------------------------------
              function refuserToucheEntree(event) {
                  // Compatibilité IE / Firefox
                  if(!event && window.event) {
                      event = window.event;
                  }
                  // IE
                  if(event.keyCode == 13) {
                      event.returnValue = false;
                      event.cancelBubble = true;
                  }
                  // DOM
                  if(event.which == 13) {
                      event.preventDefault();
                      event.stopPropagation();
                  }
              }
      // -------------------------------------------------------------------------      FIN / THE END !      -------------------------------------------------------------------------

        var elm_tempo = document.getElementById("g");

        var timeout;
        var lastTap = 0;

        elm_tempo.addEventListener("touchend", function(event){
          var currentTime = new Date().getTime();
          var tapLength = currentTime - lastTap;
          clearTimeout(timeout);

          if (tapLength < 500 && tapLength > 0) {
            test_1 = chaine.split(' ');
            test_2 = "matrix(1, 0, 0, 1, " + test_1[4] + ", " + test_1[5];

            if (cible == "course_1" || cible == "course_2" || cible == "course_3" || cible == "course_4" || cible == "course_1" || cible == "passe_1" || cible == "passe_2" || cible == "passe_3" || cible == "passe_4" || cible == "passe_5") {
              setTimeout(rotationMAJ, 300);
            }
            if (cible == "raquette_1" || cible == "raquette_2" || cible == "raquette_3" || cible == "bloquer_1" || cible == "bloquer_2" || cible == "bloquer_3" || cible == "drive_1" || cible == "drive_2" || cible == "drive_3" || cible == "course_ecran_1" || cible == "course_ecran_2") {
              setTimeout(rotationMAJ, 300);
            }

            event.preventDefault();


          } else {
            timeout = setTimeout(function() {
              clearTimeout(timeout);
            }, 500);
          }

          lastTap = currentTime;
        });

      </script>
    </svg> <br> <br>

    <div class="btn">
      <a class="btn-add" onclick="sendData()"><input type="button" value="Enregistrer"></a>
      <a class="btn-add" onclick="renitialise()"><input type="button" value="Réinitialiser"></a>
      <?php echo "<a class=\"btn-add\" href=\"../Controler/liste_des_schemas.ctrl.php?nom_systeme=".$this->nom_fichier."\"><input type=\"button\" value=\"Retour\"></a>"; ?>
    </div>
  </div>
  </form>
</body>
</html>
