<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="../View/css/classement.css">
    <title>Classement</title>
</head>
<body>
<h1>Classement</h1>
<div>
<table>
    <tr><th>Position</th><th>Nom</th><th>Pts</th><th>J</th><th>G</th><th>P</th><th>N</th></tr>
<?php
    foreach($this->tabEquipes as $elem) {
        print("<tr>");
        //Récupération de la position
        print("<td>");
        print($elem->getPositionEquipe());
        print("</td>");
        //Récupération du nom
        print("<td>");
        print($elem->getNomEquipe());
        print("</td>");
        print("<td>");
        print($elem->getNbPointsEquipe());
        print("</td>");
        print("<td>");
        print($elem->getNbRencontres_jouees());
        print("</td>");
        print("<td>");
        print($elem->getNbRencontres_gagnees());
        print("</td>");
        print("<td>");
        print($elem->getNbRencontres_perdues());
        print("</td>");
        print("<td>");
        print($elem->getNbRencontres_nulles());
        print("</td>");
        ("</tr>\n");
    }
?>
</table>
<p>Copyright © 2020 - Données extraites du site web de la FFBB - Copyright Holder All Rights Reserved.</p>
</div>
<footer>
<?php require_once("../View/menu.view.php") ?>
</footer>
</body>
</html>
