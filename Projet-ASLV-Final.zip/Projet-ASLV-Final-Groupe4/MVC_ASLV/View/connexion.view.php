<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="../View/css/connexion.css" />
    <link rel="icon" href="../View/img/logo2.jpg" />
    <title> ASLV - Connexion</title>
  </head>
  <body>
    <div class="titre">
        <h1>Connectez - Vous</h1>
    </div>

    <section id="Container-Connexion">
        <form method="post" action="" name="Co" id="Form-Connexion">
          <section id="infoperso1">
            <section id="info-Co">
                <input type="text" name="pseudo" placeholder="Identifiant" id="EM" value="<?php if(isset($this->pseudo)) {echo $this->pseudo;} ?>"/>
                <h3> Votre identifiant est votre l’adresse mail. </h3>
                <input type="password" name="password" minlength="6" placeholder="Mot de passe" id="Pass"/>
            </section>

            <section id="Boutons">
              <p>
                <input type="submit" name="formconnexion" value="Connexion" id="envoi">
              </p>
            </section>
          </section>
        </form>

        <div id="info-supp">
            <a href="#" class="A-Deco"> <h2> Identifiant ou mot de passe oublié ? </h2> </a>
        </div>

        <?php
           //si on recois un message derreur l'afficher
           if(isset($this->erreur_msg)) {
              echo "<p id=\"erreur_msg\">",$this->erreur_msg,"</p>";
           }
        ?>
    </section>
  </body>
</html>
