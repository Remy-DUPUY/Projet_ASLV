<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Grande vue schema</title>
    <style media="screen">
      body{
        text-align: center;
      }

      h1 {
        text-align: center;
      }

      a{
        text-decoration: none;
        color: black;
      }

      .btn-add > input{
        background-color: #DAD9D9;
        border : solid 0.5em #C82619;
        border-radius: 10px;
        color: black;
        border: none;
        padding: 20px 30px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
      }
    </style>
  </head>
  <body>
    <h1> Visualisation final : </h1>
    <svg width="535" height="750">
      <g>
        <defs>
          <pattern id="image" patternUnits="userSpaceOnUse" height="750" width="500">
            <image x="0" y="0" height="750" width="500" xlink:href="../View/img/basket.png"></image>
          </pattern>
          <pattern id="image1" height="5" width="5">
            <image x="0" y="0" height="65" width="65" xlink:href="../View/img/maillot/1.png"></image>
          </pattern>
          <pattern id="image2" height="5" width="5">
            <image x="0" y="0" height="65" width="65" xlink:href="../View/img/maillot/2.png"></image>
          </pattern>
          <pattern id="image3" height="5" width="5">
            <image x="0" y="0" height="65" width="65" xlink:href="../View/img/maillot/3.png"></image>
          </pattern>
          <pattern id="image4" height="5" width="5">
            <image x="0" y="0" height="65" width="65" xlink:href="../View/img/maillot/4.png"></image>
          </pattern>
          <pattern id="image5" height="5" width="5">
            <image x="0" y="0" height="65" width="65" xlink:href="../View/img/maillot/5.png"></image>
          </pattern>

          <pattern id="image6" height="5" width="5">
            <image x="0" y="0" height="25" width="25" xlink:href="../View/img/logo-ballon.png"></image>
          </pattern>

          <pattern id="arrow_1.1" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow.png"></image>
          </pattern>
          <pattern id="arrow_2.1" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow.png"></image>
          </pattern>
          <pattern id="arrow_3.1" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow.png"></image>
          </pattern>
          <pattern id="arrow_4.1" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow.png"></image>
          </pattern>
          <pattern id="arrow_5.1" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow.png"></image>
          </pattern>

          <pattern id="arrow_1.1_p" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-pointie.png"></image>
          </pattern>
          <pattern id="arrow_2.1_p" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-pointie.png"></image>
          </pattern>
          <pattern id="arrow_3.1_p" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-pointie.png"></image>
          </pattern>
          <pattern id="arrow_4.1_p" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-pointie.png"></image>
          </pattern>
          <pattern id="arrow_5.1_p" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-pointie.png"></image>
          </pattern>

          <pattern id="raquette_img" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-raquette.png"></image>
          </pattern>
          <pattern id="raquette_img_2" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-raquette.png"></image>
          </pattern>
          <pattern id="raquette_img_3" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-raquette.png"></image>
          </pattern>

          <pattern id="bloquer_img" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-bloquer.png"></image>
          </pattern>
          <pattern id="bloquer_img_2" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-bloquer.png"></image>
          </pattern>
          <pattern id="bloquer_img_3" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-bloquer.png"></image>
          </pattern>

          <pattern id="drive_img" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-drive.png"></image>
          </pattern>
          <pattern id="drive_img_2" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-drive.png"></image>
          </pattern>
          <pattern id="drive_img_3" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-drive.png"></image>
          </pattern>

          <pattern id="course_img" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-course.png"></image>
          </pattern>
          <pattern id="course_img_2" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-course.png"></image>
          </pattern>
          <pattern id="course_img_3" height="5" width="5">
            <image x="0" y="0" width="70" height="50" xlink:href="../View/img/logo-arrow-course.png"></image>
          </pattern>
        </defs>

        <!-- Rect  -->
        <rect x="0" y="0" width="535" height="750" stroke="#0E0E0E" fill="url(#image)" />

        <!-- Forme signifiant les joueuses -->
        <rect id="arrow"    x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[7] ?>" stroke-width="1" stroke="" fill="url(#arrow_1.1)" />
        <rect id="arrow_2"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[8] ?>" stroke-width="1" stroke="" fill="url(#arrow_2.1)" />
        <rect id="arrow_3"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[9] ?>" stroke-width="1" stroke="" fill="url(#arrow_3.1)" />
        <rect id="arrow_4"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[10] ?>" stroke-width="1" stroke="" fill="url(#arrow_4.1)" />
        <rect id="arrow_5"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[11] ?>" stroke-width="1" stroke="" fill="url(#arrow_5.1)" />

        <rect id="arrow_p1"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[12] ?>" stroke-width="1" stroke="" fill="url(#arrow_1.1_p)" />
        <rect id="arrow_p2"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[13] ?>" stroke-width="1" stroke="" fill="url(#arrow_2.1_p)" />
        <rect id="arrow_p3"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[14] ?>" stroke-width="1" stroke="" fill="url(#arrow_3.1_p)" />
        <rect id="arrow_p4"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[15] ?>" stroke-width="1" stroke="" fill="url(#arrow_4.1_p)" />
        <rect id="arrow_p5"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[16] ?>" stroke-width="1" stroke="" fill="url(#arrow_5.1_p)" />

        <rect id="raquette"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[17] ?>" stroke-width="1" stroke="" fill="url(#raquette_img)" />
        <rect id="raquette_2"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[18] ?>" stroke-width="1" stroke="" fill="url(#raquette_img_2)" />
        <rect id="raquette_3"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[19] ?>" stroke-width="1" stroke="" fill="url(#raquette_img_3)" />

        <rect id="bloquer"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[20] ?>" stroke-width="1" stroke="" fill="url(#bloquer_img)" />
        <rect id="bloquer_2"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[21] ?>" stroke-width="1" stroke="" fill="url(#bloquer_img_2)" />
        <rect id="bloquer_3"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[22] ?>" stroke-width="1" stroke="" fill="url(#bloquer_img_3)" />

        <rect id="drive"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[23] ?>" stroke-width="1" stroke="" fill="url(#drive_img)" />
        <rect id="drive_2"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[24] ?>" stroke-width="1" stroke="" fill="url(#drive_img_2)" />
        <rect id="drive_3"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[25] ?>" stroke-width="1" stroke="" fill="url(#drive_img_3)" />

        <rect id="course"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[26] ?>" stroke-width="1" stroke="" fill="url(#course_img)" />
        <rect id="course_2"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[27] ?>" stroke-width="1" stroke="" fill="url(#course_img_2)" />
        <rect id="course_3"  x="0"  y="0" width="70" height="50" transform="<?= $this->tab_schema[28] ?>" stroke-width="1" stroke="" fill="url(#course_img_3)" />

        <ellipse id="joueuse_1" cx="0" cy="0" rx="35" ry="37" transform="<?= $this->tab_schema[1] ?>" stroke-width="1" stroke="" fill="url(#image1)" />
        <ellipse id="joueuse_2" cx="0" cy="0" rx="35" ry="37" transform="<?= $this->tab_schema[2] ?>" stroke-width="1" stroke="" fill="url(#image2)"  />
        <ellipse id="joueuse_3" cx="0" cy="0" rx="35" ry="37" transform="<?= $this->tab_schema[3] ?>" stroke-width="1" stroke="" fill="url(#image3)"  />
        <ellipse id="joueuse_4" cx="0" cy="0" rx="35" ry="37" transform="<?= $this->tab_schema[4] ?>" stroke-width="1" stroke="" fill="url(#image4)"  />
        <ellipse id="joueuse_5" cx="0" cy="0" rx="35" ry="37" transform="<?= $this->tab_schema[5] ?>" stroke-width="1" stroke="" fill="url(#image5)"  />

        <ellipse id="ballon"    cx="0" cy="0" rx="12.5" ry="12.5" transform="<?= $this->tab_schema[6] ?>" stroke-width="1" stroke="#0E0E0E" fill="url(#image6)"  />
      </g>
    </svg> <br> <br>

    <?php
      echo "<a class=\"btn-add\" href=\"../Controler/liste_des_schemas.ctrl.php?nom_systeme=".$this->nom_fichier."\"><input type=\"button\" value=\"Retour\"></a>";
    ?>
  </body>
</html>
