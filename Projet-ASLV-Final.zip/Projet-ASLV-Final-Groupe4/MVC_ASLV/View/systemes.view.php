<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>

    <style media="screen">
      a{
        text-decoration: none;
        color: black;
      }

      #plus{
        width: 60px;
        height: auto;
      }

      .un_system{
        width: 60%;
        margin: auto;
        border: 1px solid black;
      }

      body{
        text-align: center;
      }

      .corps{
        margin-bottom: 55px;
      }

      .img-plus {
        width: 10px;
        height: 10px;
      }

      /*Barre de menu*/
      #logo_systemes {
        background-color: #D5DBDB;
      }

      .img-plus > img{
        width: auto;
        height: 30px;
        margin-right: 15px;
      }

      .btn-buttom-container{
          text-align: center;
          width: 50%;
          margin: auto;
          display: flex;
          justify-content: space-around;
      }
    </style>

    <link rel="stylesheet" href="../View/css/systemes.css">

  </head>
  <body>
    <div class="corps">


    <h1>Systèmes</h1>


    <a class="btn-add" href="../Controler/addSysteme.ctrl.php"><input type="button" value="Ajouter un système"></a>
    <br><br>





    <?php

    foreach ($system_all as $value) {
      echo "<div class=\"btn-buttom-container\">";
      if($this->btn == "envoyer") {
          echo "<a class=\"img-plus\" href=\"../Controler/modifier_systeme.ctrl.php?nom_fichier=$value[1]\">";
            echo "<img src=\"../View/img/logo-edit.png\" alt=\"edit / modifier systeme\">";
          echo "</a>";

          echo "<a class=\"img-plus\" href=\"../Controler/supprimer_systeme.ctrl.php?nom_fichier=$value[1]\">";
            echo "<img src=\"../View/img/logo-trash.png\" alt=\"trash / delette / supprimer systeme\">";
          echo "</a>";
       }
       echo "</div> <br> <br>";

        echo "<a href=\"../Controler/liste_des_schemas.ctrl.php?nom_systeme=$value[1]\">";
          echo "<div class=\"un_system\">";
            //echo "id_fichier : ".$value[1]."<br>";
            $titre = substr($value[1], 0, strlen($value[1])-5);//on enleve le ".json"
            echo "<h4>Nom du système : ".$titre."<br></h4>";
            if($value[2]!=NULL && $value[2]!=' '){
              echo "<h4>Description : ".$value[2]."<br></h4>";
            }
            echo "<h4>Date de création : ".$value[3]."<br></h4>";
          echo "</div>";
        echo "</a>";
      echo "<br><br>";
    }
    ?>

    </div>

    <?php include("../View/menu.view.php"); ?>
  </body>
</html>
