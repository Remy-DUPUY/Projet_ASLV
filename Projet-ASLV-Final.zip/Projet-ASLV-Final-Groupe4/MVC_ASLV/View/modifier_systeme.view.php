<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="../View/css/modification_systeme.css" />
    <title> Modification Systéme</title>
  </head>
  <body>

    <form method="post" action="" name="Co" id="Form-modification">
      <section id="infos">
        <section id="info-titre">
            <input type="text" name="nouveau_titre" placeholder="Titre" id="EM" value="<?php echo "$nom_fichier"; ?>" required/>
            <h3> Nom du système </h3>
            <input type="text" name="desc" placeholder="Aucune description" id="EM" value="<?php echo "$description"; ?>"/>
            <h3> Description du système </h3>
        </section>

        <section id="Boutons">
          <p>
            <input type="submit" name="formmodification" value="Valider" id="envoi">
          </p>
        </section>
      </section>
    </form>
    <?php
       //si on recois un message derreur l'afficher
       if(isset($this->erreur_msg)) {
          echo "<p id=\"Erreur1\">",$this->erreur_msg,"</p>";
       }
    ?>

  </body>
</html>
