<!DOCTYPE html>
<html lang="en" dir="ltr" >
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../View/css/creer_exercices.view.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
  </head>
  <body>
      <h1> Exercice </h1>
      <form class="" action="../Controler/exercice.ctrl.php" method="POST">
          <div>
              <label for="Exercice" id="l1">Nom de l'exercice: </label>
              <input id="saisie" type="text" name="Nom_Exercice" value="<?php if(isset($this->nom)) {echo $this->nom;} ?>">
              <br>

              <label for="Nb_serie" id="l2"> Nombres de séries : </label>
              <input type="number" name="Nb_serie" id="saisie" value="<?php if(isset($this->serie)) {echo $this->serie;} ?>">
              <br>

              <label for="Nb_rep" id="l3"> Nombres de répétitions : </label>
              <input type="number" name="Nb_rep" id="saisie" value="<?php if(isset($this->rep)) {echo $this->rep;} ?>">
              <br>

              <label for="pause" id="l4"> Repos: </label>
              <input class="dernier" type="number" name="repos" id="saisie" value="<?php if(isset($this->repos)) {echo $this->repos;} ?>">sec
              <br><br>
          </div>
      <input id="btn" type="submit" name="formExo" value="Valider">
      </form>

      <?php
         //si on recois un message derreur l'afficher
         if(isset($this->erreur_msg)) {
            echo "<p id=\"erreur_msg\">",$this->erreur_msg,"</p>";
         }
      ?>
  </body>
</html>
