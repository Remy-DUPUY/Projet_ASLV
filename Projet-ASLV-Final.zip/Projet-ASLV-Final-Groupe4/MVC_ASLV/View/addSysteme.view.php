<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Créer un Système</title>
    <link rel="stylesheet" href="../View/css/style.css">
    
  </head>
  <body>
    <div id="container">
        <div class="Titre">
          <h1>Nouveau Système</h1>
        </div>

        <form class="" action="" method="post">
            <div class="box1">
              <div id="Saisie">
                <h3 id="T-Saisie">Titre :</h3>
                <input id="C-Saisie" type="text" name="titre" required minlength="1" maxlength="22" size="25" height="80" value="<?php if(isset($titre)) {echo $titre ;} ?>">
              </div>

              <div class="btn">
                <a class="btn-add"><input name="button_systeme" type="submit" value="Valider"></a>
                <a class="btn-add" href="../Controler/systemes.ctrl.php?"><input type="button" value="Annuler"></a>
              </div>
            </div>
          </form>

          <?php
            if(isset($msg_erreur)) {
                echo "<p id=\"erreur_msg\">",$msg_erreur,"</p>";
            }
          ?>
      </div>
  </body>
</html>
