<?php
  header("Location: Controler/systemes.ctrl.php");
?>
