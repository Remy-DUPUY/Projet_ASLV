<?php
  session_start();
  require_once("../Model/Exercice.class.php");

  require_once("../Model/ExerciceDAO.class.php");
  require_once('../Model/membre.class.php');
  include("../Framework/view.class.php");

  $view = new View("../View/exercice.view.php");

  if(isset($_SESSION['unMembre'])) {
    // on recupère le membre connecté que l'on de serialize
    $m = unserialize($_SESSION['unMembre']);

    $ExerciceDAO = new ExerciceDAO();
    //$id = $ExerciceDAO->getLastId()+1;
    if(isset($_POST['Nom_Exercice']) && isset($_POST['Nb_serie']) && isset($_POST['Nb_rep']) && isset($_POST['repos'])) {
      if(!empty($_POST['Nom_Exercice']) AND !empty($_POST['Nb_serie']) AND !empty($_POST['Nb_rep']) AND !empty($_POST['repos'])) {
        // htmlspecialchars permet de supprimer les balises que pourrer utiliser un hacker ou personne mal intensionner
        $nom = htmlspecialchars($_POST["Nom_Exercice"]);
        $serie = htmlspecialchars($_POST["Nb_serie"]);
        $rep = htmlspecialchars($_POST["Nb_rep"]);
        $repos = htmlspecialchars($_POST["repos"]);

        $ExerciceDAO->insertExercice($nom,$serie,$rep,$repos);
      }
    }

    $exercices = $ExerciceDAO->getAllExercices();
    echo "<h1>Préparation physique</h1><br>";
    $nb_exercices = sizeof($exercices);

      printf("<div class='corps'>");
    for($i=0; $i<$nb_exercices; $i++){
      printf("<div class='ex12'>");
      printf("<div class='ex1'>");
      printf("<p>Nom de l'exercice:&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp %s",$exercices[$i]->getNom());
      printf("<br>Nombre de séries à effectuer: &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp %d",$exercices[$i]->getSerie());
      printf("<br>Nombre de répétitions: &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp %d",$exercices[$i]->getRepetition());
      printf("<br>Temps de pause entre chaque série: &nbsp %s sec</p>",$exercices[$i]->getRepos());
      printf("</div>");
      printf("<div class='ex2'>");

      if($m->get_pseudo() == "coach"){ // A REMPLACER PAR TEST COMPTE CONNECTE
        echo "<button onclick=\"supprimeExo(" . $exercices[$i]->getId() . ")\">Supprimer</button>";
      }
      printf("</div>");
      printf("</div>");
      printf("<br><br>");
    }
    if($m->get_pseudo() == "coach"){
      printf("<div class='bouton_ajouter'>");
      printf("<a href='../Controler/creer_exercices.ctrl.php'><input type='button' value='Ajouter'></a>");
      printf("</div>");
    }
    printf("<br><br>");
    } else {
      header("Location: ../Controler/connexion.ctrl.php");
    }

    printf("</div>");

  $view->show();
?>
