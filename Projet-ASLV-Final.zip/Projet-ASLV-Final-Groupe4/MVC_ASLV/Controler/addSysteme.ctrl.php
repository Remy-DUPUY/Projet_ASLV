<?php
session_start();
require_once('../Model/systemeDAO.class.php');
require_once('../Model/systeme.class.php');
include("../Framework/view.class.php");

require_once('../Model/membre.class.php');

if(isset($_SESSION['unMembre'])) {
      // on recupère le membre connecté que l'on de serialize
      $m = unserialize($_SESSION['unMembre']);

      $view = new View("../View/addSysteme.view.php");

      if (isset($_POST['button_systeme'])) {
      if(!empty($_POST['titre'])) {
        $titre = htmlspecialchars($_POST['titre']);
          $s_file = $titre . ".json";

          if(!file_exists("../Model/data/$s_file")){

                $systeme = new SystemeDAO();


                // si le nom est pas trouvé on continue
                if($systeme->exists($s_file) == 0) {
                  // on crée le fichier avec le nom données par l'utilisateur
                  $fichier = fopen("../Model/data/$s_file", 'w');
                  fclose($fichier);

                  $id_fichier = uniqid();
                  $dateNow = date('d/m/Y - H:i');

                  // on ajoute en base le system
                  $systeme->insert($s_file);


                  header("Location: ../Controler/liste_des_schemas.ctrl.php?nom_systeme=$s_file");
                } else {
                  $view->msg_erreur = "ERREUR: Le système est déjà enregistré ...";
                }
          }else{
            $view->msg_erreur = "ERREUR: Le système existe déja !";
          }
        }else{
            $view->msg_erreur = "ERREUR: Titre non saisie";
        }

      }

      $view->show();

} else {
  header("Location: ../Controler/connexion.ctrl.php");
}


?>
