<?php
  session_start();
  require_once('../Model/membreDAO.class.php');
  require_once('../Model/membre.class.php');

  require_once('../Model/systemeDAO.class.php');
  require_once('../Model/systeme.class.php');
  include("../Framework/view.class.php");
  $view = new View("../View/systemes.view.php");

  if(isset($_SESSION['unMembre'])) {
    //on créer l'objet
    $systeme = new SystemeDAO();

    //On récupére un tableau de tous les objet systéme
    $view->system_all = $systeme->getAll();

    // on recupère le membre connecté que l'on de serialize
    $m = unserialize($_SESSION['unMembre']);

    if ($m->get_pseudo() == "coach") {
        $view->btn = "envoyer";
    } else {
        $view->btn = "no";
    }
  } else {
      header("Location: ../Controler/connexion.ctrl.php");
  }

  $view->show();
 ?>
