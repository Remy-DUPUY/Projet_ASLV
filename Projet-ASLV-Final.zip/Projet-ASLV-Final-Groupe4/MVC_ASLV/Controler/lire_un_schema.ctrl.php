<?php
    session_start();
    require_once('../Model/membre.class.php');

    include("../Framework/view.class.php");
    $view = new View("../View/lire_un_schema.view.php");

    if(isset($_SESSION['unMembre'])) {
        // chemin d'accès à votre fichier JSON
        $file = $_GET['nom_fichier'];
        // nom du shcema qu'on edite
        if(isset($_GET['nom_schema']) and $_GET['nom_schema'] != NULL) {
          $nom_schema = $_GET['nom_schema'];
        } else{
          $fileData = file_get_contents("../Model/data/".$file);
          $tableau_pour_json = json_decode($fileData, true);
          $nom_schema = "schema_strategie_".(count($tableau_pour_json)-1);
        }

        // mettre le contenu du fichier dans une variable
        $data = file_get_contents("../Model/data/".$file);
        // décoder le flux JSON
        $obj = json_decode($data);
        // var_dump($obj);

        // on initialise les matrices
        // JOUEUSES
        $tab_schema[1] = $obj->$nom_schema->joueuse_1;
        $tab_schema[2] = $obj->$nom_schema->joueuse_2;
        $tab_schema[3] = $obj->$nom_schema->joueuse_3;
        $tab_schema[4] = $obj->$nom_schema->joueuse_4;
        $tab_schema[5] = $obj->$nom_schema->joueuse_5;
        // BALLON
        $tab_schema[6] = $obj->$nom_schema->ballon;
        //ARROW SIMPLE
        $tab_schema[7] = $obj->$nom_schema->arrow;
        $tab_schema[8] = $obj->$nom_schema->arrow_2;
        $tab_schema[9] = $obj->$nom_schema->arrow_3;
        $tab_schema[10] = $obj->$nom_schema->arrow_4;
        $tab_schema[11] = $obj->$nom_schema->arrow_5;
        // ARROW POINITLLIER
        $tab_schema[12] = $obj->$nom_schema->arrow_p1;
        $tab_schema[13] = $obj->$nom_schema->arrow_p2;
        $tab_schema[14] = $obj->$nom_schema->arrow_p3;
        $tab_schema[15] = $obj->$nom_schema->arrow_p4;
        $tab_schema[16] = $obj->$nom_schema->arrow_p5;
        // AUTRE ARROW ET OBJET
        $tab_schema[17] = $obj->$nom_schema->raquette;
        $tab_schema[18] = $obj->$nom_schema->raquette_2;
        $tab_schema[19] = $obj->$nom_schema->raquette_3;

        $tab_schema[20] = $obj->$nom_schema->bloquer;
        $tab_schema[21] = $obj->$nom_schema->bloquer_2;
        $tab_schema[22] = $obj->$nom_schema->bloquer_3;

        $tab_schema[23] = $obj->$nom_schema->drive;
        $tab_schema[24] = $obj->$nom_schema->drive_2;
        $tab_schema[25] = $obj->$nom_schema->drive_3;

        $tab_schema[26] = $obj->$nom_schema->course;
        $tab_schema[27] = $obj->$nom_schema->course_2;
        $tab_schema[28] = $obj->$nom_schema->course_3;

        $view->nom_fichier = $file;
        $view->nom_schema = $nom_schema;

        $view->tab_schema = $tab_schema;

    } else {
        header("Location: ../Controler/connexion.ctrl.php");
    }
    $view->show();
?>
