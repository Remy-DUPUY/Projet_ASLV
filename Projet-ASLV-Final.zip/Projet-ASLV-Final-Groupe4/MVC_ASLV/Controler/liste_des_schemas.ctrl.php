<?php
  session_start();
  require_once('../Model/membre.class.php');

  include("../Framework/view.class.php");
  $view = new View("../View/liste_des_schemas.view.php");

  if(isset($_SESSION['unMembre'])) {
      // on doit connaitre le nom du system qu'on veux visualiser
      // chemin d'accès à votre fichier JSON
      if (isset($_GET['nom_systeme'])) {
        $file = $_GET['nom_systeme'];
      } else {
        header("Location: ../Controler/systemes.ctrl.php");
      }

      // mettre le contenu du fichier dans une variable
      $data = file_get_contents("../Model/data/".$file);
      // décoder le flux JSON
      $obj = json_decode($data);
      // var_dump($obj);

      // on initialise les tableaux
      $tab_tempo = array();
      $tab_schema = array();
      $tab_name_schema = array();
      $tab_titre_schema = array();

      for ($i=0; $i < 20; $i++) {
        $nom_schema = "schema_strategie_$i";
        $j = 1;

        if ($obj->$nom_schema != NULL) {
          $tab_name_schema[] = $nom_schema;
          $tab_titre_schema[] = $obj->$nom_schema->titre_schema;

          // on initialise les matrices
          $tab_tempo[1] = $obj->$nom_schema->joueuse_1;
          $tab_tempo[2] = $obj->$nom_schema->joueuse_2;
          $tab_tempo[3] = $obj->$nom_schema->joueuse_3;
          $tab_tempo[4] = $obj->$nom_schema->joueuse_4;
          $tab_tempo[5] = $obj->$nom_schema->joueuse_5;
          // BALLON
          $tab_tempo[6] = $obj->$nom_schema->ballon;
          //ARROW SIMPLE
          $tab_tempo[7] = $obj->$nom_schema->arrow;
          $tab_tempo[8] = $obj->$nom_schema->arrow_2;
          $tab_tempo[9] = $obj->$nom_schema->arrow_3;
          $tab_tempo[10] = $obj->$nom_schema->arrow_4;
          $tab_tempo[11] = $obj->$nom_schema->arrow_5;
          // ARROW POINITLLIER
          $tab_tempo[12] = $obj->$nom_schema->arrow_p1;
          $tab_tempo[13] = $obj->$nom_schema->arrow_p2;
          $tab_tempo[14] = $obj->$nom_schema->arrow_p3;
          $tab_tempo[15] = $obj->$nom_schema->arrow_p4;
          $tab_tempo[16] = $obj->$nom_schema->arrow_p5;
          // AUTRE ARROW ET OBJET
          $tab_tempo[17] = $obj->$nom_schema->raquette;
          $tab_tempo[18] = $obj->$nom_schema->raquette_2;
          $tab_tempo[19] = $obj->$nom_schema->raquette_3;

          $tab_tempo[20] = $obj->$nom_schema->bloquer;
          $tab_tempo[21] = $obj->$nom_schema->bloquer_2;
          $tab_tempo[22] = $obj->$nom_schema->bloquer_3;

          $tab_tempo[23] = $obj->$nom_schema->drive;
          $tab_tempo[24] = $obj->$nom_schema->drive_2;
          $tab_tempo[25] = $obj->$nom_schema->drive_3;

          $tab_tempo[26] = $obj->$nom_schema->course;
          $tab_tempo[27] = $obj->$nom_schema->course_2;
          $tab_tempo[28] = $obj->$nom_schema->course_3;

          for ($p=1; $p < 7; $p++) {
            // on recupere juste les 2 derniers nombres ----- si on a cette matrice : matrix(1 0 0 1 165 250) on recupere "165 et 250"

            $decoupe = substr($tab_tempo[$p], 15,-1);

            // une fois qu'on a recuperer nos 2 chiffre on doit les decouper ----- "165 et 250" donne $explode[0] = 165 et $explode[1] = 250
            $explode = explode(" ", $decoupe);

            // on reforme la matrice
            $val_0 = 535 - intval($explode[0]); // HAUTEUR
            $val_1 = intval($explode[1]); // LARGEUR

            $tab_tempo[$p] = "matrix(1 0 0 1 $val_1 $val_0) rotate(-90)";

          }
          for ($s=7; $s < 29; $s++) {
            // on recupere juste les 2 derniers nombres ----- si on a cette matrice : matrix(1 0 0 1 165 250) on recupere "165 et 250"
            $decoupe = substr($tab_tempo[$s], 15,-1);

            // une fois qu'on a recuperer nos 2 chiffre on doit les decouper ----- "165 et 250" donne $explode[0] = 165 et $explode[1] = 250
            $explode = explode(" ", $decoupe);

            // on reforme la matrice
            $val_0 = 535 - intval($explode[0]);
            $val_1 = intval($explode[1]);

            $res_tempo = substr($tab_tempo[$s],-11,11);
            if($res_tempo[1] == ')') {
              $res_tempo = substr($res_tempo, 2);
            } else if ($res_tempo[0] == ')') {
              $res_tempo = substr($res_tempo, 1);
            }

            $res_tempo = substr($res_tempo, 7);
            $res_tempo = substr($res_tempo, 0, -1);

            $res_tempo = intval($res_tempo)-90;

            $res_tempo = "rotate(".$res_tempo.")";

            $tab_tempo[$s] = "matrix(1 0 0 1 $val_1 $val_0) ". $res_tempo;
            // var_dump(substr("rotate(45)",-11,11));
            // var_dump(substr("rotate(180)",-11,11));
          }

          $tab_schema[] = $tab_tempo;
        }
      }

      // var_dump($tab_name_schema);
      // var_dump($tab_titre_schema);

      $view->nom_fichier = $file;
      $view->tab_schema = $tab_schema;
      $view->tab_name_schema = $tab_name_schema;
      $view->tab_titre_schema = $tab_titre_schema;

      // on recupère le membre connecté que l'on de serialize
      $m = unserialize($_SESSION['unMembre']);

      if ($m->get_pseudo() == "coach") {
          $view->btn = "envoyer";
      } else {
          $view->btn = "no";
      }
  } else {
    header("Location: ../Controler/connexion.ctrl.php");
  }

  $view->show();
?>
