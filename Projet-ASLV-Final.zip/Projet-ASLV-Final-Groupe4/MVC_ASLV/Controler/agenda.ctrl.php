<?php
  session_start();
  require_once('../Model/membre.class.php');
  include("../Framework/view.class.php");

  $view = new View('../View/agenda.view.php');

  if(isset($_SESSION['unMembre'])) {
    // nothing
  } else {
      header("Location: ../Controler/connexion.ctrl.php");
  }

  $view->show();
?>
