<?php
  // on recupêre les informations qui se trouve dans URL
  if (isset($_GET['nom_fichier']) && isset($_GET['nom_schema'])) {
    $nom_fichier = $_GET['nom_fichier'];
    $nom_schema = $_GET['nom_schema'];

    // on decode le json
    $data = file_get_contents("../Model/data/".$nom_fichier);
    $obj = json_decode($data, true);

    // on met la partie de lobjet qui nous interresse pour la dupliquer
    $obj_tab = $obj[$nom_schema];

    // on modifie l'id du nouveau schema
    $obj_tab['id'] = "Schema_".uniqid();

    $obj["schema_strategie_".count($obj)] = $obj_tab;

    $contenu_json = json_encode($obj);
    file_put_contents("../Model/data/".$nom_fichier, $contenu_json, JSON_FORCE_OBJECT);

    header("Location: ../Controler/liste_des_schemas.ctrl.php?nom_systeme=$nom_fichier");
  } else{
    header("Location: ../Controler/systemes.ctrl.php");
  }
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <style media="screen">
    .btn-add > input{
      background-color: #DAD9D9;
      border : solid 0.5em #C82619;
      border-radius: 10px;
      color: black;
      border: none;
      padding: 20px 30px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
    }
    </style>
  </head>
  <body>
    <?php echo "<a class=\"btn-add\" href=\"../Controler/liste_des_schemas.ctrl.php?nom_systeme=$nom_fichier\"><input type=\"button\" value=\"Retour\"></a>"; ?>
  </body>
</html>
