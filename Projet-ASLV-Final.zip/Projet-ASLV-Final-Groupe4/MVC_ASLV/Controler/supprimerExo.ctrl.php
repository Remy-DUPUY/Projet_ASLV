<?php
  require_once("../Model/ExerciceDAO.class.php");
  require_once('../Model/Exercice.class.php');
  $ExerciceDAO = new ExerciceDAO();

  if(isset($_POST["yes"])) {
    if ($_POST["yes"] == "true") {
      $ExerciceDAO->deleteExercice($_POST["id_p"]);
    }
  }
 ?>
