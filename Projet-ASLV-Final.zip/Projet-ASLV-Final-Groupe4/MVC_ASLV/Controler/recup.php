<?php

     if (isset($_POST['titre_schema']) and $_POST['titre_schema'] != NULL) {
       $titre_schema = $_POST['titre_schema'];
     } else {
       $titre_schema = "Pas de nom fourni";
     }

     $table_objet_1 = $_POST['table_objet'];
     $table_objet_2 = explode(",",$table_objet_1);
     $table_objet = array();
     $j = 0;
     for ($i=0; $i < count($table_objet_2); ($i=$i+2)) {
       $var = $i+1;
       $table_objet[$j] = array($table_objet_2[$i],$table_objet_2[$var]);
       $j ++;
     }

     // encoder dans le json
     $nom_fichier = $_POST['nom_systeme'];
     if (isset($nom_fichier)) {
       $tab_tempo = array();

       try {
           // On essayes de récupérer le contenu existant
           $s_fileData = file_get_contents("../Model/data/".$nom_fichier);

           if( !$s_fileData || strlen($s_fileData) == 0 ) {
               // On crée le tableau JSON
               $tableau_pour_json = array();
           } else {
               // On récupère le JSON dans un tableau PHP
               $tableau_pour_json = json_decode($s_fileData, true);
           }

           // On ajoute le nouvel élement
           $tab_tempo['id'] = "Schema_".uniqid();
           $tab_tempo['titre_schema'] = $titre_schema;

           for ($i=0; $i < count($table_objet); $i++) {
             $tab_tempo[$table_objet[$i][0]] = $table_objet[$i][1];
           }

           /*
            foreach ($table_objet as $key => $value) {
              $tab_tempo[$key] = [
                'nom_objet' => $value[0],
                'matrice' => $value[1]
              ];
            }*/

            // gestion du nom de fichier json ou l'on rendre les données
            if(isset($_POST['nom_schema']) and $_POST['nom_schema'] != NULL) {
              $schema_name = $_POST['nom_schema'];
              unset($tableau_pour_json->$schema_name);
              $tableau_pour_json[$schema_name] = $tab_tempo;
            } else {
              $schema_name = "schema_strategie_".count($tableau_pour_json);
              $tableau_pour_json["schema_strategie_".count($tableau_pour_json)] = $tab_tempo;
            }

          // On réencode en JSON
           $contenu_json = json_encode($tableau_pour_json);

           // On stocke tout le JSON
           file_put_contents("../Model/data/".$nom_fichier, $contenu_json, JSON_FORCE_OBJECT);

           echo "Vos informations ont été enregistrées !";
       }
       catch( Exception $e ) {
           echo "Erreur : ".$e->getMessage();
       }
     } else {
       echo "probleme on nous a pas fournie le nom de systeme !";
     }
?>
