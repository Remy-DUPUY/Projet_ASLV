<?php
  session_start();
  require_once('../Model/membreDAO.class.php');
  require_once('../Model/membre.class.php');
  include("../Framework/view.class.php");

  $view = new View("../View/connexion.view.php");

  // on regarde si on a bien recu le formulaire de connexion (si la variable n'est pas null)
  if(isset($_POST['formconnexion'])) {
      // htmlspecialchars: utilisée pour convertir des caractères spéciaux
      // cela evite qu'on puisse faire passer un code pour potentiellement hack la base de donne ou autre
      $pseudo = htmlspecialchars($_POST['pseudo']);
      $password = htmlspecialchars($_POST['password']);
      $view->pseudo = $pseudo;

      // on verifie si elle ne sont pas vide
      if( (isset($pseudo) and isset($password)) AND (!empty($pseudo) and !empty($password)) ){
              // On cree un objet membre
              $membre = new MembreDAO();
              // on verifie si le speudo fournie dans lurl fait partie d'un membre coach ou joueuses
              $membre_exist = $membre->speudo_exist($pseudo);
              // si le resultat renvoyer par la fonctuon est 1 le mail exite dans la base de donné
              if($membre_exist == 1) {
                  // a partir de du speudo on cree un membre
                  $UnMembre = $membre->getMembre($pseudo);
                  // on verifie si le mot de passe correcpond a celui contenue dans la base de donne
                  if ($membre->verif_password($password, $UnMembre)) {
                       // session est est une variable qui nous permet de faire passer des information entre les pages
                       // est va avec la function session_start(); qui est debut de chaque page qui aurait besoin de savoir
                       // si un membre est déjà connecté

                       // serialize des données signifie convertir une valeur en une séquence de bits
                       // nous utilisons cette function pour faire passer l'bojet memebre. car un objet utilise des poiteurs.
                       $_SESSION['unMembre'] = serialize($UnMembre);
                       // une fois connecté on rediriger sur la page d'acceuil
                       header("Location: ../index.php");
                  } else {
                     $erreur_msg = "Mauvais mot de passe !";
                     $view->erreur_msg = $erreur_msg;
                  }
              } else {
                    $erreur_msg = "Mauvais pseudo !";
                    $view->erreur_msg = $erreur_msg;
              }
          }else{
              $erreur_msg = "Tous les champs doivent être complétés !";
              $view->erreur_msg = $erreur_msg;
          }
      }else{
          $erreur_msg = "Tous les champs doivent être complétés !";
          $view->erreur_msg = $erreur_msg;
      }
      //echo password_hash("0123456789", PASSWORD_DEFAULT);
  $view->show();
?>
