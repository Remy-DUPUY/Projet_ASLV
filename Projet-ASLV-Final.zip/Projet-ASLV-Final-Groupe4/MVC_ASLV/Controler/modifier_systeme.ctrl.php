<?php
  session_start();
  require_once('../Model/membre.class.php');

  include("../Framework/view.class.php");
  require_once("../Model/systemeDAO.class.php");
  require_once('../Model/systeme.class.php');
  $view = new View("../View/modifier_systeme.view.php");

  if(isset($_SESSION['unMembre'])) {
      $systeme = new SystemeDAO();

      $nom_fichier = $_GET['nom_fichier'];


      if(isset($_POST['formmodification'])) {

        $nouveau_titre = htmlspecialchars($_POST['nouveau_titre']);
        $desc = htmlspecialchars($_POST['desc']);

        if( (isset($nouveau_titre)AND (!empty($nouveau_titre)) )){

              if(rename("../Model/data/".$nom_fichier,"../Model/data/".$nouveau_titre.".json")){


                $systeme->setNom($nom_fichier,$nouveau_titre.".json");

                if(isset($desc) && $desc != null){
                  $systeme->setDescription($nouveau_titre.".json", $desc);

                  header("Location: ../index.php");
                }else if ($desc == null){
                  $systeme->setDescription($nouveau_titre.".json", ' ');

                  header("Location: ../index.php");
                }



              }else{

                $erreur_msg = "Erreur de modification du fichier du systéme, nom_fichier=$nom_fichier , nouveau_titre=$nouveau_titre  ";
                $view->erreur_msg = $erreur_msg;
              }


        }else{
            $erreur_msg = "Le titre ne doit pas être vide !";
            $view->erreur_msg = $erreur_msg;
        }

      }else {

        if(isset($nom_fichier)){

          $view->nom_fichier = substr($nom_fichier, 0, strlen($nom_fichier)-5);//on enleve le ".json"

          if($systeme->get($nom_fichier)->getDescription() == ' '){
            $view->description = null;
          }else{
            $view->description = $systeme->get($nom_fichier)->getDescription();
          }

          //$systeme->delete($nom_fichier); // suprimme dans la table & sur le FTP le fichier .json
          //header("Location: ../Controler/systemes.ctrl.php");

        }else{
          echo "Nom du fichier à modifier non fournie !";
          echo "</br>";
        }

      }
  } else {
    header("Location: ../Controler/connexion.ctrl.php");
  }


  $view->show();
 ?>
