<?php
  session_start();
  require_once('../Model/membre.class.php');

  require_once("../Model/Exercice.class.php");
  require_once("../Model/ExerciceDAO.class.php");
  include("../Framework/view.class.php");

  if(isset($_SESSION['unMembre'])) {
      $view = new View("../View/creer_exercices.view.php");

      $ExerciceDAO = new ExerciceDAO();

      if(isset($_POST['formExo'])) {
          // htmlspecialchars permet de supprimer les balises que pourrer utiliser un hacker ou personne mal intensionner
          $nom = htmlspecialchars($_POST["Nom_Exercice"]);
          $serie = htmlspecialchars($_POST["Nb_serie"]);
          $rep = htmlspecialchars($_POST["Nb_rep"]);
          $repos = htmlspecialchars($_POST["repos"]);

          $view->nom = $nom;
          $view->serie = $serie;
          $view->rep = $rep;
          $view->repos = $repos;

          // on test si le contenue du post est pas null ni vide
          if(isset($_POST['Nom_Exercice']) AND isset($_POST['Nb_serie']) AND isset($_POST['Nb_rep']) OR isset($_POST['repos'])) {
              if(!empty($_POST['Nom_Exercice']) AND !empty($_POST['Nb_serie']) AND !empty($_POST['Nb_rep']) OR !empty($_POST['repos']) ) {
                // on test si un exo du nom donné n'existe pas déjà si renvoie false cest que le nom n'est pas en base de données
                if (!$ExerciceDAO->exo_exist($nom)) {
                  $ExerciceDAO->insertExercice($nom, $serie, $rep, $repos);
                  header("Location: ../Controler/exercice.ctrl.php");
                } else {
                  $erreur_msg = "Un exercice du meme nom existe déjà !";
                  $view->erreur_msg = $erreur_msg;
                }
              } else {
                $erreur_msg = "Tous les champs doivent être complétés !";
                $view->erreur_msg = $erreur_msg;
              }
          }
      }
  } else {
      header("Location: ../Controler/connexion.ctrl.php");
  }

  $view->show();
?>
