<?php
  session_start();
  require_once('../Model/membre.class.php');

  include("../Framework/view.class.php");
  $view = new View("../View/dessiner_un_schema.view.php");

  if(isset($_SESSION['unMembre'])) {
      // chemin d'accès à votre fichier JSON
      $nom_fichier = $_GET['nom_fichier'];
      // nom du shcema qu'on edite
      $nom_schema = $_GET['nom_schema'];

      // mettre le contenu du fichier dans une variable
      $data = file_get_contents("../Model/data/".$nom_fichier);
      $obj = json_decode($data); // décoder le flux JSON

      // on initialise les matrices
      if($_GET['nom_schema'] == '' OR $_GET['nom_schema'] == NULL){
        // JOUEUSES
        $tab_schema[1] = "matrix(1 0 0 1 497 75)";
        $tab_schema[2] = "matrix(1 0 0 1 497 130)";
        $tab_schema[3] = "matrix(1 0 0 1 497 185)";
        $tab_schema[4] = "matrix(1 0 0 1 497 240)";
        $tab_schema[5] = "matrix(1 0 0 1 497 295)";
        // BALLON
        $tab_schema[6] = "matrix(1 0 0 1 494 350)";
        //ARROW SIMPLE
        $tab_schema[7] = "matrix(1 0 0 1 462 381)rotate(0)";
        $tab_schema[8] = "matrix(1 0 0 1 462 381)rotate(0)";
        $tab_schema[9] = "matrix(1 0 0 1 462 381)rotate(0)";
        $tab_schema[10] = "matrix(1 0 0 1 462 381)rotate(0)";
        $tab_schema[11] = "matrix(1 0 0 1 462 381)rotate(0)";
        // ARROW POINITLLIER
        $tab_schema[12] = "matrix(1 0 0 1 462 420)rotate(0)";
        $tab_schema[13] = "matrix(1 0 0 1 462 420)rotate(0)";
        $tab_schema[14] = "matrix(1 0 0 1 462 420)rotate(0)";
        $tab_schema[15] = "matrix(1 0 0 1 462 420)rotate(0)";
        $tab_schema[16] = "matrix(1 0 0 1 462 420)rotate(0)";
        // AUTRE ARROW ET OBJET
        $tab_schema[17] = "matrix(1 0 0 1 462 460)rotate(0)";
        $tab_schema[18] = "matrix(1 0 0 1 462 460)rotate(0)";
        $tab_schema[19] = "matrix(1 0 0 1 462 460)rotate(0)";

        $tab_schema[20] = "matrix(1 0 0 1 462 510)rotate(0)";
        $tab_schema[21] = "matrix(1 0 0 1 462 510)rotate(0)";
        $tab_schema[22] = "matrix(1 0 0 1 462 510)rotate(0)";

        $tab_schema[23] = "matrix(1 0 0 1 462 540)rotate(0)";
        $tab_schema[24] = "matrix(1 0 0 1 462 540)rotate(0)";
        $tab_schema[25] = "matrix(1 0 0 1 462 540)rotate(0)";

        $tab_schema[26] = "matrix(1 0 0 1 462 570)rotate(0)";
        $tab_schema[27] = "matrix(1 0 0 1 462 570)rotate(0)";
        $tab_schema[28] = "matrix(1 0 0 1 462 570)rotate(0)";
      } else {
        // JOUEUSES
        $tab_schema[1] = $obj->$nom_schema->joueuse_1;
        $tab_schema[2] = $obj->$nom_schema->joueuse_2;
        $tab_schema[3] = $obj->$nom_schema->joueuse_3;
        $tab_schema[4] = $obj->$nom_schema->joueuse_4;
        $tab_schema[5] = $obj->$nom_schema->joueuse_5;
        // BALLON
        $tab_schema[6] = $obj->$nom_schema->ballon;
        //ARROW SIMPLE
        $tab_schema[7] = $obj->$nom_schema->arrow;
        $tab_schema[8] = $obj->$nom_schema->arrow_2;
        $tab_schema[9] = $obj->$nom_schema->arrow_3;
        $tab_schema[10] = $obj->$nom_schema->arrow_4;
        $tab_schema[11] = $obj->$nom_schema->arrow_5;
        // ARROW POINITLLIER
        $tab_schema[12] = $obj->$nom_schema->arrow_p1;
        $tab_schema[13] = $obj->$nom_schema->arrow_p2;
        $tab_schema[14] = $obj->$nom_schema->arrow_p3;
        $tab_schema[15] = $obj->$nom_schema->arrow_p4;
        $tab_schema[16] = $obj->$nom_schema->arrow_p5;
        // AUTRE ARROW ET OBJET
        $tab_schema[17] = $obj->$nom_schema->raquette;
        $tab_schema[18] = $obj->$nom_schema->raquette_2;
        $tab_schema[19] = $obj->$nom_schema->raquette_3;

        $tab_schema[20] = $obj->$nom_schema->bloquer;
        $tab_schema[21] = $obj->$nom_schema->bloquer_2;
        $tab_schema[22] = $obj->$nom_schema->bloquer_3;

        $tab_schema[23] = $obj->$nom_schema->drive;
        $tab_schema[24] = $obj->$nom_schema->drive_2;
        $tab_schema[25] = $obj->$nom_schema->drive_3;

        $tab_schema[26] = $obj->$nom_schema->course;
        $tab_schema[27] = $obj->$nom_schema->course_2;
        $tab_schema[28] = $obj->$nom_schema->course_3;
      }

      $view->nom_fichier = $nom_fichier;
      $view->nom_schema = $nom_schema;
      $view->tab_schema = $tab_schema;
  } else {
    header("Location: ../Controler/connexion.ctrl.php");
  }

  $view->show();
?>
