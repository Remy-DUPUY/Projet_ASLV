<?php
  // chemin d'accès à votre fichier JSON
  $nom_fichier = $_GET['nom_fichier'];
  $nom_schema = $_GET['nom_schema'];

  if (isset($nom_fichier) && isset($nom_schema)) {
    // mettre le contenu du fichier dans une variable
    $data = file_get_contents("../Model/data/".$nom_fichier);
    // décoder le flux JSON
    $obj = json_decode($data, true);

    // on supprime l'objet schema voulue
    unset($obj[$nom_schema]);

    $tab_tempo = array();
    for ($i=0; $i < count($obj)+1; $i++) {
      if($obj["schema_strategie_$i"] != null){
        $tab_tempo[] = $obj["schema_strategie_$i"];
      }
    }

    $obj_tab = array();

    for ($j=0; $j < count($tab_tempo); $j++) {
      $obj_tab["schema_strategie_$j"] = $tab_tempo[$j];
    }

    // On réencode en JSON
     $contenu_json = json_encode($obj_tab);

     // On stocke tout le JSON
     file_put_contents("../Model/data/".$nom_fichier, $contenu_json, JSON_FORCE_OBJECT);

     header("Location: ../Controler/liste_des_schemas.ctrl.php?nom_systeme=$nom_fichier");
  } else {
     header("Location: ../Controler/systemes.ctrl.php");
  }

?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <style media="screen">
    .btn-add > input{
      background-color: #DAD9D9;
      border : solid 0.5em #C82619;
      border-radius: 10px;
      color: black;
      border: none;
      padding: 20px 30px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
    }
    </style>
  </head>
  <body>
    <?php echo "<a class=\"btn-add\" href=\"../Controler/liste_des_schemas.ctrl.php?nom_systeme=$nom_fichier\"><input type=\"button\" value=\"Retour\"></a>"; ?>
  </body>
</html>
