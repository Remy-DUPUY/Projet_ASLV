<?php
session_start();
require_once('../Model/membre.class.php');

require_once("../Model/classementDAO.class.php");
require_once("../Framework/view.class.php");

if(isset($_SESSION['unMembre'])) {
  // Recuperation des donnees de configuration
  $config = parse_ini_file("../Config/config.ini");

  // Creation de l'instace DAO
  $classement = new ClassementDAO();

  //Recuperation des donnees du site web
  $tabEquipes = $classement->getInfosSite($config['cheminSiteWeb']);

  //Mise a jour ou insertion des donnees dans la table classement en fonction de la
  //situation de la table

  if($classement->estVide()) {
      $classement->insereBDD($tabEquipes);
  }else {
      $classement->updateBDD($tabEquipes);
  }

  //Recuperation des donnees de la base
  $tabClassementEquipes = $classement->getEquipesClassement();
  $view = new View('../View/classement.view.php');

  if(isset($_SESSION['unMembre'])) {

  } else {
      header("Location: ../Controler/connexion.ctrl.php");
  }

  $view->tabEquipes = $tabClassementEquipes;
} else {
  header("Location: ../Controler/connexion.ctrl.php");
}
$view->show();
?>
