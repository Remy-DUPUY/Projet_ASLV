<?php
  require_once("../Model/systemeDAO.class.php");
  require_once('../Model/systeme.class.php');
  $systeme = new SystemeDAO();

  $nom_fichier = $_GET['nom_fichier'];

  if(isset($nom_fichier)){
    $systeme->delete($nom_fichier); // suprimme dans la table & sur le FTP le fichier .json

    header("Location: ../Controler/systemes.ctrl.php");

  }else{
    echo "Nom du fichier à supprimer non fournie !";
    header("Location: ../Controler/systemes.ctrl.php");
  }


 ?>
